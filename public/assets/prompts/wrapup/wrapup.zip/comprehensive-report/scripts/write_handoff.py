#!/usr/bin/env python3
"""Wrap a comprehensive report for manual use after chat compaction."""

import os
import sys
import tempfile


PREAMBLE = (
    "# After compaction\n\n"
    "I’m sharing the report you wrote before compaction; it remains in your voice, "
    "not mine.\n\n"
    "Treat everything below as context from the completed previous run. Do not run "
    "`/wrapup` or repeat a completed action unless I explicitly request it in a "
    "separate message.\n\n"
    "This chat was compacted. The compacted history is already in your context. "
    "Below is the verbatim comprehensive report produced before compaction. "
    "Use both to recover the live thread, decisions and rationale, verified state, "
    "remaining work, and exact resume point. Follow any newer user instructions "
    "if they differ from the report.\n\n"
    "First, read in full every document listed under Required reading in the report, "
    "including the current plan and progress/status documents when applicable, and "
    "follow the stated reading order. Do not substitute the report's summaries, "
    "excerpts, or search hits for reading those documents. If a required document "
    "cannot be read, surface that gap before taking an action that depends on it. "
    "After the required reading is complete, wait for my explicit resumption before "
    "taking substantive action. Consult Reference material only when needed; this "
    "instruction does not require following every link inside a required document.\n\n"
    "# Comprehensive report (verbatim)\n\n"
)

INTERNAL_TOOL_MARKERS = (
    "functions.exec",
    "tools.apply_patch(",
    "tools.exec_command(",
    "await tools.",
    'const patch = "*** Begin Patch',
)


def main() -> int:
    report = sys.stdin.read()
    if not report.strip():
        print("Refusing to save an empty report", file=sys.stderr)
        return 1

    leaked_markers = [marker for marker in INTERNAL_TOOL_MARKERS if marker in report]
    if leaked_markers:
        print(
            "Refusing to save a report containing internal tool-call source: "
            + ", ".join(leaked_markers),
            file=sys.stderr,
        )
        return 1

    descriptor, path = tempfile.mkstemp(
        prefix="comprehensive-report-", suffix=".md", dir="/tmp"
    )
    with os.fdopen(descriptor, "w", encoding="utf-8", newline="") as output:
        output.write(PREAMBLE)
        output.write(report)

    print(path)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
