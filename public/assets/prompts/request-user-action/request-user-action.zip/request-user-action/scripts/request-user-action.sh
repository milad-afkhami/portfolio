#!/usr/bin/env bash

set -u

title="Action needed"
message=""
done_label="Completed"
cancel_label="Can't complete"
extra_label=""
width="520"

usage() {
  printf '%s\n' \
    'Usage: request-user-action.sh --message TEXT [options]' \
    '' \
    'Options:' \
    '  --title TEXT         Dialog title (default: Action needed)' \
    '  --message TEXT       Required instructions for the user' \
    '  --done-label TEXT    Completion button label (default: Completed)' \
    "  --cancel-label TEXT  Cancellation button label (default: Can't complete)" \
    '  --extra-label TEXT   Optional alternate-action button label' \
    '  --width PIXELS       Dialog width (default: 520)' \
    '  --help               Show this help'
}

require_value() {
  if [ "$#" -lt 2 ] || [ -z "$2" ]; then
    printf 'Missing value for %s\n' "$1" >&2
    usage >&2
    exit 64
  fi
}

while [ "$#" -gt 0 ]; do
  case "$1" in
    --title)
      require_value "$@"
      title=$2
      shift 2
      ;;
    --message)
      require_value "$@"
      message=$2
      shift 2
      ;;
    --done-label)
      require_value "$@"
      done_label=$2
      shift 2
      ;;
    --cancel-label)
      require_value "$@"
      cancel_label=$2
      shift 2
      ;;
    --extra-label)
      require_value "$@"
      extra_label=$2
      shift 2
      ;;
    --width)
      require_value "$@"
      width=$2
      shift 2
      ;;
    --help|-h)
      usage
      exit 0
      ;;
    *)
      printf 'Unknown option: %s\n' "$1" >&2
      usage >&2
      exit 64
      ;;
  esac
done

if [ -z "$message" ]; then
  printf '%s\n' 'A non-empty --message is required.' >&2
  usage >&2
  exit 64
fi

case "$width" in
  ''|*[!0-9]*)
    printf '%s\n' '--width must be a positive integer.' >&2
    exit 64
    ;;
esac

if [ "$width" -lt 1 ]; then
  printf '%s\n' '--width must be a positive integer.' >&2
  exit 64
fi

if ! command -v zenity >/dev/null 2>&1; then
  printf '%s\n' 'DIALOG_UNAVAILABLE' >&2
  exit 3
fi

if [ -z "${DISPLAY:-}" ] && [ -z "${WAYLAND_DISPLAY:-}" ]; then
  export DISPLAY=:1
fi

play_attention_sound() {
  if command -v canberra-gtk-play >/dev/null 2>&1 &&
    canberra-gtk-play --id=dialog-warning --description="$title" >/dev/null 2>&1; then
    return
  fi

  for candidate in \
    /usr/share/sounds/freedesktop/stereo/dialog-warning.oga \
    /usr/share/sounds/Yaru/stereo/dialog-warning.oga
  do
    if [ -f "$candidate" ] && command -v pw-play >/dev/null 2>&1 &&
      pw-play "$candidate" >/dev/null 2>&1; then
      return
    fi

    if [ -f "$candidate" ] && command -v paplay >/dev/null 2>&1 &&
      paplay "$candidate" >/dev/null 2>&1; then
      return
    fi
  done

  if [ -f /usr/share/sounds/alsa/Front_Center.wav ] && command -v aplay >/dev/null 2>&1 &&
    aplay -q /usr/share/sounds/alsa/Front_Center.wav >/dev/null 2>&1; then
    return
  fi

  if [ -w /dev/tty ]; then
    printf '\a' >/dev/tty 2>/dev/null || true
  else
    printf '\a' >&2
  fi
}

play_attention_sound

zenity_args=(
  --question
  --title="$title"
  --width="$width"
  --ok-label="$done_label"
  --cancel-label="$cancel_label"
  --text="$message"
  --icon=dialog-warning
  --no-markup
  --default-cancel
)

if [ -n "$extra_label" ]; then
  zenity_args+=(--extra-button="$extra_label")
fi

choice=$(zenity "${zenity_args[@]}" 2>/dev/null)
dialog_status=$?

if [ "$dialog_status" -eq 0 ]; then
  printf '%s\n' 'COMPLETED'
  exit 0
fi

if [ -n "$extra_label" ] && [ "$choice" = "$extra_label" ]; then
  printf 'ALTERNATE:%s\n' "$extra_label"
  exit 10
fi

if [ "$dialog_status" -eq 1 ] || [ "$dialog_status" -eq 5 ]; then
  printf '%s\n' 'CANCELLED'
  exit 2
fi

printf 'DIALOG_ERROR:%s\n' "$dialog_status" >&2
exit 3
