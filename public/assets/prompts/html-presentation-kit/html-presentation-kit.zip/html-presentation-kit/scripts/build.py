#!/usr/bin/env python3
"""Assemble a slides source file into a self-contained HTML deck, and optionally a PDF.

The source holds only what is specific to one deck: a JSON config block, theme
CSS, and <section class="slide"> elements. This script wraps it with the
runtime (deck.js), engine styles (deck.css), the vendored Tailwind browser
build, and base64-embedded fonts, so the output opens anywhere, offline.

Usage:
  build.py talk.slides.html                 -> talk.html
  build.py talk.slides.html --pdf           -> talk.html + talk.pdf
  build.py talk.slides.html --check         -> overflow + font report (exit 1 on issues)
  build.py talk.slides.html --pdf --png DIR -> also rasterize PDF pages to DIR for review

Standard library only. PDF and --check need Chrome/Chromium on PATH (or $CHROME).
"""
import argparse
import base64
import html
import json
import os
import re
import shutil
import subprocess
import sys
import tempfile
from html.parser import HTMLParser
from pathlib import Path

KIT = Path(__file__).resolve().parent.parent
RUNTIME = KIT / "assets" / "runtime"
FONT_DIR = RUNTIME / "fonts"

LATIN_RANGE = ("U+0000-00FF,U+0131,U+0152-0153,U+02BB-02BC,U+02C6,U+02DA,U+02DC,U+0304,"
               "U+0308,U+0329,U+2000-206F,U+20AC,U+2122,U+2191,U+2193,U+2212,U+2215,U+FEFF,U+FFFD")
ARABIC_RANGE = "U+0600-06FF,U+0750-077F,U+0870-08FF,U+200C-200E,U+2010-2011,U+204F,U+2E41,U+FB50-FDFF,U+FE70-FEFC"

# Bundled fonts (all SIL OFL). key -> family, weight axis, files, generic fallback.
FONTS = {
    "vazirmatn": {"family": "Vazirmatn", "weight": "100 900", "fallback": "Tahoma, sans-serif",
                  "files": [("vazirmatn-arabic-wght-normal.woff2", "normal", ARABIC_RANGE),
                            ("vazirmatn-latin-wght-normal.woff2", "normal", LATIN_RANGE)]},
    "nunito": {"family": "Nunito", "weight": "200 1000", "fallback": "system-ui, sans-serif",
               "files": [("nunito-latin-wght-normal.woff2", "normal", None),
                         ("nunito-latin-wght-italic.woff2", "italic", None)]},
    "lexend": {"family": "Lexend", "weight": "100 900", "fallback": "system-ui, sans-serif",
               "files": [("lexend-latin-wght-normal.woff2", "normal", None)]},
    "lora": {"family": "Lora", "weight": "400 700", "fallback": "Georgia, serif",
             "files": [("lora-latin-wght-normal.woff2", "normal", None),
                       ("lora-latin-wght-italic.woff2", "italic", None)]},
    "jetbrains-mono": {"family": "JetBrains Mono", "weight": "100 800", "fallback": "ui-monospace, monospace",
                       "files": [("jetbrains-mono-latin-wght-normal.woff2", "normal", None)]},
}
RTL_LANGS = {"fa", "ar", "he", "ur", "ps", "ku", "ckb"}
MIME = {".woff2": "font/woff2", ".woff": "font/woff", ".ttf": "font/ttf", ".otf": "font/otf"}

TAILWIND_THEME = """@theme inline {
  --color-bg: var(--deck-bg);
  --color-fg: var(--deck-fg);
  --color-muted: var(--deck-muted);
  --color-accent: var(--deck-accent);
  --color-accent-2: var(--deck-accent-2);
  --color-surface: var(--deck-surface);
  --color-line: var(--deck-line);
  --font-sans: var(--deck-font-body);
  --font-body: var(--deck-font-body);
  --font-display: var(--deck-font-display);
  --font-mono: var(--deck-font-mono);
}"""


def die(msg):
    print(f"error: {msg}", file=sys.stderr)
    sys.exit(2)


# --------------------------------------------------------------------------- source parsing

CONFIG_RE = re.compile(r'<script[^>]*id=["\']deck-config["\'][^>]*>(.*?)</script>', re.S | re.I)
STYLE_RE = re.compile(r'<style\b[^>]*>.*?</style>|<link\b[^>]*rel=["\']?stylesheet[^>]*>', re.S | re.I)


def parse_source(text):
    m = CONFIG_RE.search(text)
    cfg = {}
    if m:
        try:
            cfg = json.loads(m.group(1))
        except json.JSONDecodeError as e:
            die(f"deck-config is not valid JSON: {e}")
        text = text[:m.start()] + text[m.end():]
    styles = STYLE_RE.findall(text)
    body = STYLE_RE.sub("", text).strip()
    return cfg, styles, body


# --------------------------------------------------------------------------- bidi isolation

SKIP_TAGS = {"code", "pre", "kbd", "samp", "script", "style", "bdi", "bdo", "svg", "math", "textarea", "template"}
VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "source", "track", "wbr"}
L = r"A-Za-zÀ-ɏ"
# A run of Latin text: starts with a letter/digit (or @/#), may contain spaces and
# in-word punctuation, ends on a letter/digit or a closing bracket/symbol.
LATIN_RUN = re.compile(rf"[@#<>≤≥~±$€£]?[{L}0-9](?:[{L}0-9 .,:;'’+\-_/&%#@()\[\]!?*=<>·•|→←]*[{L}0-9+#%)\]])?")
HAS_LETTER = re.compile(rf"[{L}]")
# Space- or dash-separated digit groups (phone numbers, card numbers). Bidi reverses
# the group order inside RTL text, so these get pinned to LTR.
DIGIT_GROUPS = re.compile(r"(?<![0-9۰-۹٠-٩])\+?[0-9۰-۹٠-٩]{2,}(?:[ \-][0-9۰-۹٠-٩]{2,})+(?![0-9۰-۹٠-٩])")


# A number with an explicit sign (+۲۲٪, -38%, ±5). In RTL text the sign would
# otherwise resolve to the right-to-left side and read as "۲۲٪+".
SIGNED_NUM = re.compile(r"(?<![0-9۰-۹٠-٩\w])[+\-−±][0-9۰-۹٠-٩]+(?:[.,٫٬][0-9۰-۹٠-٩]+)*[%٪]?")
NOWRAP_MAX = 28  # isolated runs up to this length stay on one line ("Flat White")


def _trim_run(s):
    # drop unbalanced trailing ')' / ']' so "(API)" isolates "API" and leaves the
    # brackets to mirror with the surrounding RTL text
    while s and s[-1] in ")]" and s.count("(") + s.count("[") < s.count(")") + s.count("]"):
        s = s[:-1].rstrip()
    return s


def _isolations(text):
    spans = []
    for m in DIGIT_GROUPS.finditer(text):
        spans.append((m.start(), m.end(), '<bdi dir="ltr" class="nw">'))
    for m in SIGNED_NUM.finditer(text):
        if not any(m.start() < b and a < m.end() for a, b, _ in spans):
            spans.append((m.start(), m.end(), '<bdi dir="ltr" class="nw">'))
    for m in LATIN_RUN.finditer(text):
        run = _trim_run(m.group(0))
        if not run or not HAS_LETTER.search(run):
            continue
        s, e = m.start(), m.start() + len(run)
        if any(s < b and a < e for a, b, _ in spans):
            continue
        spans.append((s, e, '<bdi class="nw">' if len(run) <= NOWRAP_MAX else "<bdi>"))
    return sorted(spans)


ENTITY = re.compile(r"&(?:#[0-9]+|#[xX][0-9a-fA-F]+|[A-Za-z][A-Za-z0-9]*);")


def _decode_with_map(raw):
    """Unescape entities, keeping each decoded char's offset in the raw text."""
    chars, pos, i = [], [], 0
    for m in ENTITY.finditer(raw):
        for k in range(i, m.start()):
            chars.append(raw[k])
            pos.append(k)
        for ch in html.unescape(m.group(0)):
            chars.append(ch)
            pos.append(m.start())
        i = m.end()
    for k in range(i, len(raw)):
        chars.append(raw[k])
        pos.append(k)
    pos.append(len(raw))
    return "".join(chars), pos


class BidiScanner(HTMLParser):
    """Finds text runs that need <bdi> and records them as (offset, insert) edits.

    Text between two tags is scanned as one piece, entities included, so "&lt;300ms"
    or "AT&amp;T" isolate as a whole.
    """

    def __init__(self, src):
        super().__init__(convert_charrefs=False)
        self.src = src
        self.line_starts = [0]
        for i, ch in enumerate(src):
            if ch == "\n":
                self.line_starts.append(i + 1)
        self.depth = {}
        self.skip = []  # (tag, depth)
        self.edits = []
        self.seg = None  # raw offset where the current text segment starts

    def _offset(self):
        line, col = self.getpos()
        return self.line_starts[line - 1] + col

    def _text(self):
        if self.seg is None:
            self.seg = self._offset()

    def _flush(self, end=None):
        if self.seg is None:
            return
        start, self.seg = self.seg, None
        if self.skip:
            return
        raw = self.src[start:self._offset() if end is None else end]
        if not raw.strip():
            return
        text, pos = _decode_with_map(raw)
        for s, e, open_tag in _isolations(text):
            self.edits.append((start + pos[s], open_tag))
            self.edits.append((start + pos[e], "</bdi>"))

    def handle_starttag(self, tag, attrs):
        self._flush()
        if tag in VOID:
            return
        self.depth[tag] = self.depth.get(tag, 0) + 1
        a = dict(attrs)
        cls = (a.get("class") or "").split()
        if tag in SKIP_TAGS or "dir" in a or "no-bidi" in cls:
            self.skip.append((tag, self.depth[tag]))

    def handle_startendtag(self, tag, attrs):
        self._flush()

    def handle_endtag(self, tag):
        self._flush()
        if tag in VOID:
            return
        d = self.depth.get(tag, 0)
        if self.skip and self.skip[-1] == (tag, d):
            self.skip.pop()
        if d:
            self.depth[tag] = d - 1

    def handle_comment(self, data):
        self._flush()

    def handle_decl(self, decl):
        self._flush()

    def handle_data(self, data):
        self._text()

    def handle_entityref(self, name):
        self._text()

    def handle_charref(self, name):
        self._text()


def isolate_bidi(body):
    p = BidiScanner(body)
    p.feed(body)
    p.close()
    p._flush(end=len(body))
    out, last = [], 0
    for off, ins in sorted(p.edits, key=lambda x: x[0]):
        out.append(body[last:off])
        out.append(ins)
        last = off
    out.append(body[last:])
    return "".join(out), len(p.edits) // 2


# --------------------------------------------------------------------------- fonts

def b64(path):
    return base64.b64encode(Path(path).read_bytes()).decode("ascii")


def font_faces(keys, extra, src_dir):
    css, families = [], []
    for key in keys:
        f = FONTS[key]
        families.append(f["family"])
        for fname, style, urange in f["files"]:
            rule = (f"@font-face{{font-family:'{f['family']}';font-style:{style};font-weight:{f['weight']};"
                    f"font-display:block;src:url(data:font/woff2;base64,{b64(FONT_DIR / fname)}) format('woff2');")
            if urange:
                rule += f"unicode-range:{urange};"
            css.append(rule + "}")
    for x in extra:
        path = (src_dir / x["file"]).resolve()
        if not path.exists():
            die(f"extra font file not found: {path}")
        mime = MIME.get(path.suffix.lower(), "font/woff2")
        fmt = {"font/woff2": "woff2", "font/woff": "woff", "font/ttf": "truetype", "font/otf": "opentype"}[mime]
        families.append(x["family"])
        css.append(f"@font-face{{font-family:'{x['family']}';font-style:{x.get('style', 'normal')};"
                   f"font-weight:{x.get('weight', '400')};font-display:block;"
                   f"src:url(data:{mime};base64,{b64(path)}) format('{fmt}');}}")
    return "\n".join(css), families


def resolve_fonts(cfg, rtl, body, styles, src_dir):
    fonts = dict(cfg.get("fonts") or {})
    extra = cfg.get("extraFonts") or []
    extra_by_family = {x["family"].lower(): x for x in extra}
    default = "vazirmatn" if rtl else "nunito"
    body_f = fonts.get("body", default)
    display_f = fonts.get("display", body_f)
    mono_f = fonts.get("mono", "jetbrains-mono")

    def stack(name, role):
        key = name.lower()
        if key in FONTS:
            fam, fb = f"'{FONTS[key]['family']}'", FONTS[key]["fallback"]
        elif key in extra_by_family:
            x = extra_by_family[key]
            fam, fb = f"'{x['family']}'", x.get("fallback") or ("ui-monospace, monospace" if role == "mono" else "sans-serif")
        else:
            die(f"font '{name}' is neither bundled ({', '.join(FONTS)}) nor declared in extraFonts")
        if rtl and key != "vazirmatn":
            fam += ", 'Vazirmatn'"      # Persian glyphs always come from Vazirmatn
        return f"{fam}, {fb}"

    joined = body + "".join(styles)
    uses_mono = bool(re.search(r"<(code|pre|kbd|samp)\b|font-mono|--deck-font-mono", joined))
    keys = []
    for name in [body_f, display_f] + ([mono_f] if uses_mono else []):
        k = name.lower()
        if k in FONTS and k not in keys:
            keys.append(k)
    if rtl and "vazirmatn" not in keys:
        keys.append("vazirmatn")
    faces, families = font_faces(keys, extra, src_dir)
    vars_css = (f":root{{--deck-font-body:{stack(body_f, 'body')};"
                f"--deck-font-display:{stack(display_f, 'display')};"
                f"--deck-font-mono:{stack(mono_f, 'mono')};}}")
    return faces, vars_css, families


# --------------------------------------------------------------------------- icons

def icon_styles(source):
    """Embed only the Phosphor styles named in the source (no runtime fetches)."""
    weights = {m.group(1) or "regular" for m in re.finditer(
        r"(?<![\w-])ph(?:-(thin|light|bold|fill|duotone))?(?![\w-])", source)}
    if not weights:
        return "", []
    root = RUNTIME / "icons" / "phosphor"
    license_text = (root / "LICENSE").read_text(encoding="utf-8")
    parts, families, selectors = [f"/*!\n{license_text}*/"], [], []
    for weight in sorted(weights):
        family = "Phosphor" if weight == "regular" else f"Phosphor-{weight.title()}"
        families.append(family)
        selectors.append(".ph" if weight == "regular" else f".ph-{weight}")
        css = (root / weight / "style.css").read_text(encoding="utf-8")
        face = (f'@font-face{{font-family:"{family}";font-display:block;'
                'font-style:normal;font-weight:normal;'
                f'src:url(data:font/woff2;base64,{b64(root / weight / (family + ".woff2"))}) format("woff2");}}')
        # Replace upstream's multiple font formats with the embedded WOFF2.
        parts.append(re.sub(r"@font-face\s*\{[^}]*\}", lambda _: face, css, count=1))
    # Duotone overlays two glyphs using a negative left margin. Keep that pair
    # LTR and on one line inside Persian content, without changing adjacent text.
    parts.append(",".join(selectors) + "{display:inline-block;direction:ltr;unicode-bidi:isolate;white-space:nowrap;letter-spacing:0;}")
    return "\n".join(parts), families


# --------------------------------------------------------------------------- images

IMG_MIME = {".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".gif": "image/gif",
            ".webp": "image/webp", ".svg": "image/svg+xml", ".avif": "image/avif"}
IMG_SRC = re.compile(r'(<img\b[^>]*?\bsrc=)(["\'])([^"\']+)\2', re.I)
CSS_URL = re.compile(r'url\((["\']?)([^)"\']+)\1\)')


def inline_images(text, base):
    """Replace local image paths with data: URIs so the deck stays one file."""
    count = [0]

    def data_uri(ref):
        if re.match(r"^(data:|https?:|//|#)", ref):
            return None
        path = (base / ref).resolve()
        mime = IMG_MIME.get(path.suffix.lower())
        if not mime:
            return None
        if not path.exists():
            die(f"image not found: {ref} (looked in {path})")
        count[0] += 1
        return f"data:{mime};base64,{b64(path)}"

    def img(m):
        uri = data_uri(m.group(3))
        return f"{m.group(1)}{m.group(2)}{uri}{m.group(2)}" if uri else m.group(0)

    def css(m):
        uri = data_uri(m.group(2))
        return f"url('{uri}')" if uri else m.group(0)

    text = IMG_SRC.sub(img, text)
    text = CSS_URL.sub(css, text)
    return text, count[0]


# --------------------------------------------------------------------------- assembly

# Bare Tailwind utility names a deck might plausibly reuse as its own class.
TW_BARE = {"ring", "shadow", "outline", "blur", "border", "rounded", "grow", "shrink", "flex", "grid",
           "block", "inline", "hidden", "contents", "container", "columns", "invert", "grayscale",
           "sepia", "italic", "underline", "overline", "uppercase", "lowercase", "capitalize", "truncate",
           "relative", "absolute", "fixed", "sticky", "static", "visible", "invisible", "collapse", "isolate",
           "transform", "transition", "filter", "sr-only", "antialiased", "ordinal", "resize", "grow",
           "group", "peer", "list-item", "flow-root", "inline-block", "inline-flex", "drop-shadow",
           "backdrop-blur", "animate-spin", "animate-pulse", "animate-bounce", "animate-ping", "invert",
           "static", "rounded-full", "shadow-inner", "border-t", "border-b", "border-s", "border-e", "flex-1"}
SELECTOR_CLASS = re.compile(r"\.(-?[A-Za-z_][\w-]*)")


def tailwind_collisions(styles):
    names = set()
    for st in styles:
        if 'text/tailwindcss' in st[:80]:
            continue
        css = re.sub(r"/\*.*?\*/", "", st, flags=re.S)
        for sel in re.findall(r"([^{}]+)\{", css):
            names.update(SELECTOR_CLASS.findall(sel))
    return sorted(n for n in names if n in TW_BARE)


def safe_json(obj):
    return json.dumps(obj, ensure_ascii=False).replace("</", "<\\/")


def assemble(src_path):
    text = src_path.read_text(encoding="utf-8")
    cfg, styles, body = parse_source(text)
    lang = cfg.get("lang", "en")
    rtl = cfg.get("dir", "rtl" if lang.split("-")[0] in RTL_LANGS else "ltr") == "rtl"
    direction = "rtl" if rtl else "ltr"
    title = cfg.get("title") or "Presentation"

    isolated = 0
    if rtl and cfg.get("autoBidi", True):
        body, isolated = isolate_bidi(body)

    body, n_img = inline_images(body, src_path.parent)
    styles = [inline_images(st, src_path.parent)[0] for st in styles]
    faces, font_vars, families = resolve_fonts(cfg, rtl, body, styles, src_path.parent)
    icons, icon_families = icon_styles(body + "".join(styles))
    families.extend(icon_families)
    runtime_cfg = {
        "title": title,
        "lang": lang,
        "dir": direction,
        "slideNumbers": cfg.get("slideNumbers", True),
        "footer": cfg.get("footer", ""),
        "fontFamilies": families,
    }
    use_tw = cfg.get("tailwind", True)

    parts = [
        "<!doctype html>",
        f'<html lang="{html.escape(lang)}" dir="{direction}">',
        "<head>",
        '<meta charset="utf-8">',
        '<meta name="viewport" content="width=device-width, initial-scale=1">',
        '<meta name="generator" content="html-presentation-kit">',
        f"<title>{html.escape(title)}</title>",
        f"<style>{faces}</style>",
        f"<style>{icons}</style>" if icons else "",
        f"<style>{(RUNTIME / 'deck.css').read_text(encoding='utf-8')}</style>",
        f"<style>{font_vars}</style>",
    ]
    if use_tw:
        tw = (RUNTIME / "tailwind.browser.js").read_text(encoding="utf-8").replace("</script", "<\\/script")
        parts.append(f"<script>{tw}</script>")
        parts.append(f'<style type="text/tailwindcss">{TAILWIND_THEME}</style>')
    parts.extend(styles)
    parts += [
        "</head>",
        "<body>",
        '<div class="deck-viewport"><main class="deck-stage">',
        body,
        "</main></div>",
        f"<script>window.DECK_CONFIG={safe_json(runtime_cfg)};</script>",
        f"<script>{(RUNTIME / 'deck.js').read_text(encoding='utf-8')}</script>",
        "</body>",
        "</html>",
    ]
    collisions = tailwind_collisions(styles) if use_tw else []
    slides = len(re.findall(r'<section\b[^>]*class=["\'][^"\']*\bslide\b', body))
    return "\n".join(parts), {"slides": slides, "rtl": rtl, "isolated": isolated, "fonts": families, "images": n_img, "collisions": collisions}


# --------------------------------------------------------------------------- chrome

def find_chrome():
    env = os.environ.get("CHROME")
    if env:
        return env
    for c in ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "chrome"):
        p = shutil.which(c)
        if p:
            return p
    mac = "/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"
    if os.path.exists(mac):
        return mac
    die("no Chrome/Chromium found on PATH (set $CHROME)")


def chrome(args, timeout=120):
    with tempfile.TemporaryDirectory(prefix="deck-chrome-") as prof:
        cmd = [find_chrome(), "--headless=new", "--disable-gpu", "--no-sandbox", "--hide-scrollbars",
               "--no-first-run", "--no-default-browser-check", f"--user-data-dir={prof}", *args]
        return subprocess.run(cmd, capture_output=True, text=True, timeout=timeout)


def build_pdf(html_path, pdf_path):
    # --virtual-time-budget lets Tailwind generate its CSS and fonts settle before printing.
    r = chrome(["--no-pdf-header-footer", "--virtual-time-budget=15000", "--run-all-compositor-stages-before-draw",
                f"--print-to-pdf={pdf_path}", html_path.resolve().as_uri()])
    if not pdf_path.exists():
        die(f"chrome did not produce {pdf_path}\n{r.stderr[-2000:]}")


def pdf_info(pdf_path):
    if not shutil.which("pdfinfo"):
        return None
    out = subprocess.run(["pdfinfo", str(pdf_path)], capture_output=True, text=True).stdout
    pages = re.search(r"Pages:\s+(\d+)", out)
    size = re.search(r"Page size:\s+([\d.]+) x ([\d.]+)", out)
    return {"pages": int(pages.group(1)) if pages else None,
            "size": (float(size.group(1)), float(size.group(2))) if size else None}


def run_check(html_path):
    r = chrome(["--virtual-time-budget=15000", "--window-size=1400,900", "--dump-dom",
                html_path.resolve().as_uri() + "?check"])
    m = re.search(r'<pre id="deck-check-result"[^>]*>(.*?)</pre>', r.stdout, re.S)
    if not m:
        die("check produced no result (did deck.js run?)\n" + r.stderr[-1500:])
    return json.loads(html.unescape(m.group(1)))


def page_no(p):
    m = re.search(r"-(\d+)\.png$", p.name)
    return int(m.group(1)) if m else 0


def contact_sheet(pages, dest, cols=3, width=640):
    """All pages on one image, for a single-look review. Needs Pillow; skipped without it."""
    try:
        from PIL import Image, ImageDraw
    except ImportError:
        return None
    if not pages:
        return None
    h = width * 9 // 16
    gap = 14
    rows = (len(pages) + cols - 1) // cols
    sheet = Image.new("RGB", (cols * (width + gap) + gap, rows * (h + gap) + gap), (120, 124, 132))
    draw = ImageDraw.Draw(sheet)
    for i, p in enumerate(pages):
        im = Image.open(p).convert("RGB").resize((width, h))
        x, y = gap + (i % cols) * (width + gap), gap + (i // cols) * (h + gap)
        sheet.paste(im, (x, y))
        draw.rectangle([x, y, x + 34, y + 22], fill=(0, 0, 0))
        draw.text((x + 8, y + 5), str(i + 1), fill=(255, 255, 255))
    sheet.save(dest)
    return dest


# --------------------------------------------------------------------------- cli

def default_out(src):
    name = src.name
    for suf in (".slides.html", ".src.html"):
        if name.endswith(suf):
            return src.with_name(name[: -len(suf)] + ".html")
    return src.with_name(src.stem + ".deck.html")


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("source", type=Path)
    ap.add_argument("-o", "--out", type=Path, help="output HTML (default: name.slides.html -> name.html)")
    ap.add_argument("--pdf", nargs="?", const=True, default=None, help="also write a PDF (default: next to the HTML)")
    ap.add_argument("--png", type=Path, help="rasterize PDF pages into this directory (implies --pdf)")
    ap.add_argument("--dpi", type=int, default=72, help="PNG resolution; 72 gives 960x540 pages (default 72)")
    ap.add_argument("--check", action="store_true", help="report overflowing content and unloaded fonts")
    a = ap.parse_args()

    src = a.source.resolve()
    if not src.exists():
        die(f"no such file: {src}")
    out = (a.out or default_out(src)).resolve()
    if out == src:
        die("output would overwrite the source; name the source *.slides.html or pass -o")

    doc, meta = assemble(src)
    out.write_text(doc, encoding="utf-8")
    kb = out.stat().st_size / 1024
    print(f"wrote {out}  ({meta['slides']} slides, {kb:.0f} KB, {'RTL' if meta['rtl'] else 'LTR'}, "
          f"fonts: {', '.join(meta['fonts'])}" + (f", {meta['images']} images inlined" if meta["images"] else "") + (f", {meta['isolated']} bidi isolations" if meta["rtl"] else "") + ")")

    status = 0
    if meta["collisions"]:
        print("WARNING: deck CSS defines classes that are also Tailwind utilities, so both apply: "
              + ", ".join("." + c for c in meta["collisions"]) + " (rename them)")
    if a.check:
        rep = run_check(out)
        bad_fonts = [f for f, ok in rep.get("fonts", {}).items() if ok is False]
        if bad_fonts:
            print(f"FONTS NOT LOADED: {', '.join(bad_fonts)}")
            status = 1
        if rep["issues"]:
            status = 1
            print(f"{len(rep['issues'])} overflow issue(s):")
            for i in rep["issues"]:
                print(f"  slide {i['slide']}: {i['element']} {i['problem']} by ~{i['overflowPx']}px  \"{i['text']}\"")
        else:
            print(f"check ok: {rep['slides']} slides, no overflow")

    if a.pdf or a.png:
        pdf = out.with_suffix(".pdf") if a.pdf in (None, True) else Path(a.pdf).resolve()
        if pdf.exists():
            pdf.unlink()
        build_pdf(out, pdf)
        info = pdf_info(pdf)
        msg = f"wrote {pdf}"
        if info:
            msg += f"  ({info['pages']} pages, {info['size'][0]:.0f}x{info['size'][1]:.0f} pt)"
            if info["pages"] != meta["slides"]:
                print(msg)
                print(f"WARNING: PDF has {info['pages']} pages but the deck has {meta['slides']} slides "
                      "(a slide is spilling onto an extra page)")
                status = 1
                msg = None
            elif info["size"] and (abs(info["size"][0] - 960) > 1 or abs(info["size"][1] - 540) > 1):
                print(msg)
                print("WARNING: page size is not 960x540 pt (1280x720 px); @page size was ignored")
                status = 1
                msg = None
        if msg:
            print(msg)
        if a.png:
            if not shutil.which("pdftoppm"):
                die("pdftoppm not found (install poppler-utils)")
            a.png.mkdir(parents=True, exist_ok=True)
            prefix = a.png / out.stem
            for old in a.png.glob(f"{out.stem}-*.png"):
                old.unlink()
            subprocess.run(["pdftoppm", "-png", "-r", str(a.dpi), str(pdf), str(prefix)], check=True)
            print(f"wrote page images to {a.png.resolve()}")
            pages = sorted((p for p in a.png.glob(f"{out.stem}-*.png") if re.search(r"-\d+\.png$", p.name)), key=page_no)
            sheet = contact_sheet(pages, a.png / f"{out.stem}-sheet.png")
            if sheet:
                print(f"wrote contact sheet {Path(sheet).resolve()}")
    sys.exit(status)


if __name__ == "__main__":
    main()
