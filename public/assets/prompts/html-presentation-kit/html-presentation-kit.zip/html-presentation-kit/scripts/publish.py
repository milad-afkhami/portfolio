#!/usr/bin/env python3
"""Publish a built deck to a dedicated, public GitHub Pages repository.

Uses Python's standard library, Git, Chrome (for the kit's check), and an
authenticated GitHub CLI. Only sanitized HTML is uploaded; input is never modified.
"""
import argparse
import base64
import hashlib
from functools import lru_cache
from html.parser import HTMLParser
import json
import os
import re
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlparse
from urllib.request import HTTPRedirectHandler, Request, build_opener, urlopen

import build

MARKER = b"html-presentation-kit:v1\n"
MAX_BYTES = 100 * 1024 * 1024
VOID = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track", "wbr"}


class PublishError(Exception):
    pass


class APIError(PublishError):
    def __init__(self, message, status=None, github_message=None):
        super().__init__(message)
        self.status = status
        self.github_message = github_message


class NoAPIRedirects(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise PublishError("GitHub API redirected the request. Use the repository's current owner/name; authenticated redirects are refused.")


def api_urlopen(request, timeout):
    # urllib normally forwards Authorization across hosts on redirects.
    return build_opener(NoAPIRedirects()).open(request, timeout=timeout)


class PublicDeck(HTMLParser):
    """Remove actual note elements/comments, leaving inline JS/CSS data intact."""

    def __init__(self, source):
        super().__init__(convert_charrefs=False)
        self.source = source
        self.line_offsets = [0]
        self.line_offsets.extend(match.end() for match in re.finditer("\n", source))
        self.parts = []
        self.hidden = []
        self.generated = False
        self.slides = 0
        self.notes = 0

    def start(self, tag, attrs, closed=False):
        classes = {c for key, value in attrs if key == "class" for c in (value or "").split()}
        if self.hidden or "notes" in classes:
            if not self.hidden:
                self.notes += 1
            if tag not in VOID:
                # In HTML, a slash does not close a non-void element. Refuse it
                # inside notes rather than risk disagreeing with the browser.
                if closed:
                    raise PublishError("Self-closing non-void element in notes; use an explicit closing tag.")
                self.hidden.append(tag)
            return
        values = dict(attrs)
        if tag == "meta" and values.get("name") == "generator" and values.get("content") == "html-presentation-kit":
            self.generated = True
        if tag == "section" and "slide" in classes:
            self.slides += 1
        self.parts.append(self.get_starttag_text())

    def handle_starttag(self, tag, attrs):
        self.start(tag, attrs)

    def handle_startendtag(self, tag, attrs):
        self.start(tag, attrs, True)

    def handle_endtag(self, tag):
        if self.hidden:
            if tag in VOID:
                return
            if tag != self.hidden[-1]:
                raise PublishError("Unbalanced HTML inside speaker notes; fix the source and rebuild.")
            self.hidden.pop()
        else:
            self.parts.append(f"</{tag}>")

    def append(self, text):
        if not self.hidden:
            self.parts.append(text)

    def handle_data(self, data):
        self.append(data)

    def handle_entityref(self, name):
        self.reference(name, "&")

    def handle_charref(self, name):
        self.reference(name, "&#")

    def reference(self, name, prefix):
        # HTMLParser also calls these for semicolon-less text such as AT&T.
        # Preserve its exact spelling rather than inventing a semicolon.
        line, column = self.getpos()
        start = self.line_offsets[line - 1] + column
        end = start + len(prefix) + len(name)
        if self.source[end:end + 1] == ";":
            end += 1
        self.append(self.source[start:end])

    def handle_decl(self, decl):
        self.append(f"<!{decl}>")

    def handle_comment(self, data):
        pass

    def handle_pi(self, data):
        raise PublishError("Processing instructions are not supported in published decks.")

    def unknown_decl(self, data):
        raise PublishError("Unsupported HTML declaration in deck.")


def prepare_public_html(text):
    parser = PublicDeck(text)
    parser.feed(text)
    parser.close()
    if parser.hidden:
        raise PublishError("Unclosed speaker notes; fix the source and rebuild.")
    if not parser.generated or not parser.slides:
        raise PublishError("Expected a built html-presentation-kit deck, not the .slides.html source.")
    payload = "".join(parser.parts).encode("utf-8")
    if len(payload) >= MAX_BYTES:
        raise PublishError("Published HTML must be smaller than GitHub's 100 MiB file limit; compress embedded images.")
    return payload, parser.notes


@lru_cache(maxsize=1)
def credentials():
    try:
        result = subprocess.run(["gh", "auth", "token", "--hostname", "github.com"],
                                capture_output=True, text=True, timeout=10)
    except FileNotFoundError as exc:
        raise PublishError("GitHub CLI is missing. Install gh, then run gh auth login --hostname github.com.") from exc
    except subprocess.TimeoutExpired as exc:
        raise PublishError("Reading GitHub CLI credentials timed out; check gh auth status.") from exc
    if result.returncode or not result.stdout.strip():
        raise PublishError("GitHub authentication is missing. Run gh auth login --hostname github.com.")
    return result.stdout.strip()


def api(method, endpoint, data=None, missing_ok=False):
    request = Request("https://api.github.com/" + endpoint, method=method,
                      data=json.dumps(data).encode() if data is not None else None,
                      headers={"Authorization": "Bearer " + credentials(),
                               "Accept": "application/vnd.github+json", "Content-Type": "application/json",
                               "X-GitHub-Api-Version": "2022-11-28", "User-Agent": "html-presentation-kit"})
    attempts = 2 if method == "GET" else 1
    for attempt in range(attempts):
        try:
            with api_urlopen(request, timeout=30 if method == "GET" else 180) as response:
                body = response.read()
                return json.loads(body) if body else {}
        except HTTPError as exc:
            with exc:
                if missing_ok and exc.code == 404:
                    return None
                try:
                    github_message = json.loads(exc.read()).get("message", exc.reason)
                except (ValueError, AttributeError):
                    github_message = exc.reason
            message = f"GitHub {method} {endpoint} failed (HTTP {exc.code}): {github_message}."
            if exc.code in (409, 422):
                message += " Check the remote deck before retrying; no overwrite was forced."
            raise APIError(message, exc.code, github_message) from exc
        except (URLError, TimeoutError, OSError) as exc:
            if attempt + 1 < attempts:
                print(f"GitHub read interrupted; retrying once: {endpoint}", flush=True)
                continue
            raise PublishError(f"GitHub {method} {endpoint} connection failed: {exc}. "
                               "Check remote state before retrying; a write may have completed.") from exc


def decode_content(item):
    try:
        return base64.b64decode(item["content"])
    except (KeyError, TypeError, ValueError) as exc:
        raise PublishError("Cannot read the publishing repository marker.") from exc


def repository(repo, initialize):
    info = api("GET", f"repos/{repo}", missing_ok=True)
    if info is None:
        if not initialize:
            raise PublishError(f"Repository {repo} is missing or inaccessible. Use --init to create your public publishing repository.")
        owner, name = repo.split("/")
        if api("GET", "user")["login"].lower() != owner.lower():
            raise PublishError("--init can create a repository only under your authenticated personal GitHub account.")
        info = api("POST", "user/repos", {"name": name, "private": False,
                    "description": "Public HTML presentations published with html-presentation-kit", "auto_init": False})
    if info.get("private") or info.get("visibility", "public") != "public":
        raise PublishError("Use a public publishing repository so GitHub Pages does not require a paid plan. No visibility was changed.")
    if info.get("archived") or info.get("fork") or not info.get("permissions", {}).get("push"):
        raise PublishError("Publishing requires a writable, non-archived, dedicated repository (not a fork).")
    branch = info["default_branch"]
    marker = api("GET", f"repos/{repo}/contents/.nojekyll?ref={quote(branch, safe='')}", missing_ok=True)
    if marker is None:
        if not initialize:
            raise PublishError("Repository is not an empty kit publishing repository. Choose a separate empty repository and use --init.")
        try:
            heads = api("GET", f"repos/{repo}/git/matching-refs/heads")
        except APIError as exc:
            if exc.status != 409 or exc.github_message != "Git Repository is empty.":
                raise
            heads = []
        if heads:
            raise PublishError("Repository is not an empty kit publishing repository. Choose a separate empty repository and use --init.")
        api("PUT", f"repos/{repo}/contents/.nojekyll", {
            "message": "Initialize presentation hosting", "branch": branch,
            "content": base64.b64encode(MARKER).decode("ascii")})
    elif decode_content(marker) != MARKER:
        raise PublishError("Repository belongs to another site. Choose a dedicated kit publishing repository.")
    return branch


def pages_configuration(repo, branch):
    pages = api("GET", f"repos/{repo}/pages", missing_ok=True)
    if pages is not None:
        if (pages.get("cname") or pages.get("build_type") != "legacy"
                or pages.get("source") != {"branch": branch, "path": "/"}):
            raise PublishError("Existing Pages configuration differs from the kit's root/branch hosting. It was not changed.")
    return pages


def git(args, cwd=None):
    # The helper obtains credentials from gh; no token enters argv or a file.
    cmd = ["git", "-c", "credential.helper=", "-c", "credential.helper=!gh auth git-credential",
           "-c", "core.hooksPath=/dev/null", "-c", "commit.gpgsign=false", *args]
    # A caller may be inside a hook/worktree or using a custom index. None of
    # its GIT_* routing/config overrides may reach this isolated checkout.
    environment = {key: value for key, value in os.environ.items() if not key.startswith("GIT_")}
    environment["GIT_TERMINAL_PROMPT"] = "0"
    try:
        result = subprocess.run(cmd, cwd=cwd, env=environment,
                                capture_output=True, text=True, timeout=240)
    except FileNotFoundError as exc:
        raise PublishError("Git is required for publishing. Install git and try again.") from exc
    except subprocess.TimeoutExpired as exc:
        raise PublishError("Git transfer timed out. Check remote state before retrying; a push may have completed.") from exc
    if result.returncode:
        raise PublishError("Git publishing failed; no force push or automatic retry was used. "
                           "Inspect the remote before retrying. " + result.stderr.strip())
    return result.stdout.strip()


def git_remote(repo):
    return f"https://github.com/{repo}.git"


def upload(repo, branch, slug, payload, replace):
    # Git pack compression avoids a large base64 JSON upload for embedded assets.
    # Each attempt starts from fresh remote state; a normal push rejects races.
    with tempfile.TemporaryDirectory(prefix="deck-publish-") as temporary:
        checkout = Path(temporary) / "site"
        git(["clone", "--quiet", "--depth=1", "--single-branch", "--no-tags",
             "--branch", branch, "--", git_remote(repo), str(checkout)])
        marker = checkout / ".nojekyll"
        if marker.is_symlink() or not marker.is_file() or marker.read_bytes() != MARKER:
            raise PublishError("The cloned repository is no longer a kit publishing repository.")
        directory = checkout / slug
        target = directory / "index.html"
        if directory.is_symlink() or target.is_symlink() or (directory.exists() and not directory.is_dir()):
            raise PublishError("The destination is not a normal deck directory; choose another slug.")
        if target.exists():
            if not target.is_file():
                raise PublishError("The destination is not a file; choose another slug.")
            if target.read_bytes() == payload:
                print("Published content is unchanged; checking the existing public URL.", flush=True)
                return
            if not replace:
                raise PublishError(f"Deck '{slug}' already exists. Choose another --slug, or use --replace to deliberately update it.")
        directory.mkdir(exist_ok=True)
        target.write_bytes(payload)
        git(["add", "--", f"{slug}/index.html"], cwd=checkout)
        git(["-c", "user.name=HTML Presentation Kit", "-c", "user.email=html-presentation-kit@users.noreply.github.com",
             "commit", "--quiet", "-m", f"Publish {slug}"], cwd=checkout)
        git(["push", "--porcelain", "origin", f"HEAD:refs/heads/{branch}"], cwd=checkout)


def verify_url(url, payload, timeout):
    expected = hashlib.sha256(payload).hexdigest()
    deadline = time.monotonic() + timeout
    last = "deployment is not available yet"
    while time.monotonic() < deadline:
        try:
            request = Request(url + f"?kit_verify={expected}", headers={"Cache-Control": "no-cache"})
            with urlopen(request, timeout=min(10, max(1, deadline - time.monotonic()))) as response:
                body = response.read(len(payload) + 1)
                if (response.geturl().startswith("https://")
                        and response.headers.get_content_type() == "text/html"
                        and hashlib.sha256(body).hexdigest() == expected):
                    return
                last = "the host is still serving different content"
        except (URLError, TimeoutError, OSError) as exc:
            last = str(exc)
        time.sleep(min(5, max(0, deadline - time.monotonic())))
    raise PublishError(f"Upload completed, but public verification timed out: {last}. Pending URL: {url} . "
                       "Re-run the same command to verify again; identical content does not create another commit.")


def publish(path, repo, slug, initialize=False, replace=False, timeout=180):
    if not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9-]*/[A-Za-z0-9][A-Za-z0-9_.-]*", repo):
        raise PublishError("--repo must be a GitHub OWNER/REPOSITORY name.")
    if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", slug):
        raise PublishError("--slug must contain lowercase Latin letters/digits separated by single hyphens.")
    if timeout < 1:
        raise PublishError("--timeout must be a positive number of seconds.")
    payload, notes = prepare_public_html(path.read_text(encoding="utf-8"))
    with tempfile.TemporaryDirectory(prefix="deck-public-check-") as temporary:
        public_file = Path(temporary) / "index.html"
        public_file.write_bytes(payload)
        report = build.run_check(public_file)
        if report["issues"] or any(not loaded for loaded in report.get("fonts", {}).values()):
            raise PublishError("The public copy failed overflow/font checks. Fix the local source and rebuild before publishing.")
    print(f"Public copy checked: {len(payload):,} bytes; {notes} note element(s) and HTML comments removed.", flush=True)
    branch = repository(repo, initialize)
    pages = pages_configuration(repo, branch)
    upload(repo, branch, slug, payload, replace)
    if pages is None:
        pages = api("POST", f"repos/{repo}/pages", {"build_type": "legacy", "source": {"branch": branch, "path": "/"}})
    base = pages["html_url"]
    parsed = urlparse(base)
    if parsed.scheme != "https" or not parsed.hostname or not parsed.hostname.endswith(".github.io"):
        raise PublishError("GitHub did not return a default HTTPS Pages URL; inspect the repository's Pages settings.")
    url = base.rstrip("/") + f"/{slug}/"
    print(f"Waiting for anonymous HTTPS verification: {url}", flush=True)
    verify_url(url, payload, timeout)
    print(f"Public URL: {url}", flush=True)
    return url


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("html", type=Path, help="built .html file, not the source")
    parser.add_argument("--repo", required=True, help="dedicated public GitHub OWNER/REPOSITORY")
    parser.add_argument("--slug", required=True, help="stable, unique deck name, e.g. quarterly-review")
    parser.add_argument("--init", action="store_true", help="create/initialize a dedicated public repository")
    parser.add_argument("--replace", action="store_true", help="update an existing deck at this slug")
    parser.add_argument("--timeout", type=int, default=180, help="seconds to wait for public verification (default 180)")
    args = parser.parse_args()
    try:
        publish(args.html.resolve(), args.repo, args.slug, args.init, args.replace, args.timeout)
    except (PublishError, OSError, UnicodeError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
