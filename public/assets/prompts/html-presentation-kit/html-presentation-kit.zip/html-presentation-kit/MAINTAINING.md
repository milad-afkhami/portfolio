# Maintaining html-presentation-kit

Notes for whoever edits the kit, not for deck authors (they read `SKILL.md` and `reference.md`). Built 2026-09-29.

## Decisions (keep these unless the user changes them)

- **The source plus build approach.** Claude writes only `*.slides.html`, and `build.py` inlines the runtime, CSS, Tailwind and fonts.
  - Why: the user didn't want Claude rewriting the runtime for every deck, and the output has to be one self-contained file.
  - Rejected:
    - Copying a full template for every deck, which puts megabytes of base64 in context.
    - Having decks link to runtime files in the skill folder, which breaks as soon as a deck is shared.
- **The presenting tool is always English and LTR, like PowerPoint.** This covers help, presenter view, overview, counter, the progress bar, slide numbers (Latin digits, bottom right), and the keys (→ always means next), even in Persian decks. Only slide content and speaker notes follow the deck's language.
  - This is an explicit user correction from 2026-09-29. The first version mirrored the arrows and used Persian UI strings, and the user rejected both.
  - The `numerals` option was removed for the same reason, so don't add Persian page numbers back.
- **Fixed 1280×720 canvas, scaled to fit the window.** It's the only reliable way to make the PDF look identical to the screen. `@page` is `1280px 720px`, which is 960×540 pt.
- **PDF comes from headless Chrome `--print-to-pdf`.** Playwright's `save_as_pdf` ignores the `@page` size and adds white bands. Firefox isn't supported for printing.
- **Fonts:**
  - English: Nunito is the default, with Lexend and Lora also bundled.
  - Persian: Vazirmatn only. Don't give English words inside Persian text their own Latin font; the user rejected that as too complex.
  - Calibri was requested but is proprietary, so it isn't bundled.
- **Tailwind is the vendored `@tailwindcss/browser` build (v4.3.3), inlined at build time.** It works offline and adds about 280 KB to each deck.
  - Engine styles live in `@layer deck`, between Tailwind's preflight and its utilities, so a utility class on a slide wins over a primitive.
  - Canvas geometry and print rules are unlayered on purpose, so nothing can override them.
- **The frontend-design skill is invoked for each deck's look**, on both Claude and Codex. The user will install it on Codex themselves.
- **Invocation is manual only.** `disable-model-invocation: true` is set, and `agents/openai.yaml` has `allow_implicit_invocation: false`.
- **Icons: Phosphor 2.1.2 (MIT)** is bundled as unmodified CSS and WOFF2 assets for all six styles, plus its license. Each of its 1,512 icons comes in thin, light, regular, bold, fill and duotone. `build.py` embeds only the styles used in the source and isolates glyphs LTR so duotone layers align in Persian decks. Update CSS, fonts and license together (see `assets/runtime/THIRD_PARTY.md`). Chosen over Bootstrap for style range and over Tabler for a complete six-style family with a smaller per-style font. Font Awesome Free gates light/thin/duotone behind Pro; Material Symbols adds variable-font controls and a stronger Material design identity.

## client-proposal depends on this kit

`client-proposal` builds with `../html-presentation-kit/scripts/build.py` and `assets/proposal-template.slides.html`; its old `build_pdf.sh` and `deck-template.html` were removed. Any change to class names, the config format, or build flags must be checked against that template.

## Regression checks after editing

1. Build both examples plus the proposal template with `--check --png <dir>`. Each must exit 0 and produce one 960×540 pt page per slide.
2. Unit-test the bidi pass (import `scripts/build.py`, call `isolate_bidi`) on the cases that broke before:

   | input | expected result |
   |---|---|
   | `Next.js.` | trailing period stays outside the isolated run |
   | `C++`, `(API)`, `React (v18)` | brackets land on the correct side |
   | `۰۹۳۹ ۲۸۴ ۰۷۴۹` | pinned LTR |
   | `+۲۲٪`, `-38%` | pinned LTR |
   | `&lt;300ms`, `AT&amp;T` | entities stay inside the run |
   | `Node.js · PostgreSQL` | one run |
   | `Flat White` | gets the `nw` class, so it can't break across lines |
3. Run `--check` against a deliberately broken deck. It must flag all three: text clipped sideways in an `overflow:hidden` box, text overlapping the footer, and content past the slide edge. It must not flag art inside an `aria-hidden="true"` wrapper.
4. Test the live deck in a browser. Playwright blocks `file://`, so serve the folder with `python3 -m http.server`.
   - `#5` must open without a fade from slide 1.
   - In the Persian example: → goes forward, the help and presenter view are English, and the slide number sits at bottom right.

## Open items

- `scripts/verify.sh` (repo-level) calls `rg`, which isn't installed on this machine. It still passes but prints `rg: command not found`. This predates the kit.
- Presenter sync uses `postMessage` to the opener plus `BroadcastChannel`. It was tested only over `http://`; whether it works across `file://` windows is unverified.
