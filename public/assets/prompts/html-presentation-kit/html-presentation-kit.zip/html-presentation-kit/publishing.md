# Public links with GitHub Pages

Use this after building and visually reviewing a deck, when the user requests a
public link or has already authorized publication. Only generated HTML is uploaded.
The local source, HTML with notes, PDF, and surrounding directory stay local.

## Account and destination

Requires Python 3, Git, Chrome (the same as the build), and the GitHub CLI authenticated
to github.com (`gh auth login --hostname github.com`). A normal account with access
to a **public** repository is enough; no paid plan, domain, or hosting subscription
is needed. The script never upgrades a plan or changes repository visibility.

Use a dedicated repository, normally `<authenticated-login>/html-presentations`.
Get the login with `gh api --hostname github.com user --jq .login`. Honor a target
the user already selected. Never use the skill repository or an existing website
as the publishing destination. The publisher marks ownership in `.nojekyll` and
refuses repositories belonging to another site. `--init` can create a public
repository under the authenticated personal account or initialize an empty one.

## Publish and update

Resolve `KIT` to this skill's directory, then publish the **built** HTML:

```bash
python3 "$KIT/scripts/publish.py" /absolute/path/talk.html \
  --repo OWNER/html-presentations --slug talk --init
```

For subsequent new decks, omit `--init` and choose a unique slug. Slugs use lowercase
Latin letters/digits separated by hyphens. For an intentional update to the same
deck, reuse its slug and add `--replace`. A different deck must get a different slug.
Without `--replace`, a name collision fails; identical content is safe to rerun.

The publisher:

1. Removes `.notes` elements and HTML comments from a separate in-memory copy.
2. Checks that public copy for overflowing content and unloaded fonts.
3. Clones the latest publishing branch into a temporary directory, stages only
   `<slug>/index.html`, and makes a normal, non-force Git push. Git compresses embedded
   assets during transfer. Other decks are preserved, and a concurrent remote
   change rejects the push. No checkout or Git configuration in your working
   directory is changed; commits use the HTML Presentation Kit automation identity.
4. Enables default HTTPS Pages hosting from the repository's default branch/root.
   It refuses to replace a different existing Pages configuration or custom domain.
5. Waits up to 180 seconds for an **anonymous HTTPS request to return the exact
   uploaded HTML**, then prints `Public URL: https://OWNER.github.io/REPO/SLUG/`.

Open the returned public link as a recipient and exercise navigation, fragments,
overview and help. Inspect the rendered deck. The local PDF continues to come from
the normal build; it is not uploaded by this command.

## Failures and limits

- A check failure occurs before any network mutation. Fix the source and rebuild.
- Missing authentication: sign in to GitHub CLI; do not put tokens in a source file.
- A conflict requires inspecting the latest remote deck and deciding whether it is
  still the intended replacement. The publisher does not automatically retry writes.
- A verification timeout means the upload may already be committed but the public
  URL is **pending**, not verified. Re-run the same command to check again without
  another commit, or increase `--timeout`. Inspect repository Pages deployment
  status if it keeps failing. Never report successful publication from upload alone.
- GitHub limits an individual Git file to 100 MiB (the publisher rejects files at
  or above that size), the published site to 1 GB, and applies soft limits of
  100 GB/month bandwidth and 10 branch-based builds/hour. Repeated large embedded
  images also grow repository history. Compress images before approaching limits;
  do not automatically buy capacity or switch providers.

## What becomes public

The published HTML and its Git revision history are public. Anyone can download,
copy, or index them. Notes and HTML comments are removed, but this is **not a general
secret scrubber**: visible text, hidden non-note elements, attributes, images,
JavaScript, and CSS are still part of the artifact. Review the deck for its audience.
Embedded images may retain metadata. The public presenter view contains no notes;
use the local HTML to present with notes.

Replacing or deleting a page does not erase old Git commits or recipients' copies.
To withdraw a deck, delete its published path and verify it no longer serves;
purging sensitive history is a separate operation. Never promise that deleting a
link recalls a document. No authentication or password protection is provided.

GitHub Pages is for static presentations here, not operating a transactional site
or SaaS. If public Git history or these limits are unacceptable, discuss another
host; the self-contained HTML needs no changes to move elsewhere.

References: [GitHub Pages limits](https://docs.github.com/en/pages/getting-started-with-github-pages/github-pages-limits),
[repository file limits](https://docs.github.com/en/repositories/working-with-files/managing-large-files/about-large-files-on-github).
