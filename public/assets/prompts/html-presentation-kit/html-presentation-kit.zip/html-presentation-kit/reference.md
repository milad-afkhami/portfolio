# Source format reference

A source file is an HTML fragment with no `<html>`, `<head>` or `<body>`. It holds three things, in any order:

```html
<script type="application/json" id="deck-config">
{ "title": "Quarterly review", "lang": "en", "fonts": { "body": "nunito", "display": "lexend" } }
</script>

<style>
  :root { --deck-bg: #f6f7f9; --deck-fg: #111418; --deck-accent: #2b59c3; }
  /* deck-specific classes go here too */
</style>

<section class="slide">…</section>
<section class="slide">…</section>
```

`<style>` and `<link rel="stylesheet">` tags are moved into `<head>`. `<style type="text/tailwindcss">` is supported for Tailwind `@theme`/`@utility` additions. Everything else is placed, in order, inside the stage.

## Config keys

| key | default | meaning |
|---|---|---|
| `title` | `"Presentation"` | `<title>`, presenter-view header |
| `lang` | `"en"` | `fa` (or any RTL language code) makes the slide content RTL; the runtime UI stays English LTR |
| `dir` | from `lang` | force `"rtl"` / `"ltr"` |
| `fonts.body` | `nunito` (en), `vazirmatn` (fa) | bundled key or an `extraFonts` family |
| `fonts.display` | = body | headings, stats, quotes |
| `fonts.mono` | `jetbrains-mono` | code; embedded only when the deck contains code |
| `extraFonts` | `[]` | `[{"family": "Fraunces", "file": "fonts/Fraunces.woff2", "weight": "100 900", "style": "normal", "fallback": "Georgia, serif"}]`, path relative to the source; `fallback` defaults to `sans-serif` |
| `footer` | `""` | text at the bottom left of every numbered slide |
| `slideNumbers` | `true` | slide number (Latin digits) at the bottom right |
| `tailwind` | `true` | set `false` to leave out Tailwind (~280 KB smaller) |
| `autoBidi` | `true` | RTL only: automatic `<bdi>` isolation of Latin runs and digit groups |

Bundled fonts: `nunito`, `lexend`, `lora` (Latin, variable weight), `vazirmatn` (Persian and Latin), `jetbrains-mono`. All SIL OFL.

Headings default to weights 700–800. When an extra font ships a single weight, set matching `font-weight` on `h1`–`h3` and `.stat b` in the deck's `<style>`. Otherwise the browser fakes bold. A variable-weight woff2 (e.g. from `@fontsource-variable/<name>` on jsDelivr) avoids the problem.

## Theme tokens

Set these on `:root` in the source `<style>`:

| token | role | Tailwind name |
|---|---|---|
| `--deck-bg` | slide background | `bg-bg`, `text-bg` |
| `--deck-fg` | main text | `text-fg`, `bg-fg` |
| `--deck-muted` | secondary text | `text-muted` |
| `--deck-accent` | primary accent (eyebrows, bullets, stats) | `bg-accent`, `text-accent`, `border-accent` |
| `--deck-accent-2` | secondary accent | `…-accent-2` |
| `--deck-surface` | cards, inline code, table stripes | `bg-surface` |
| `--deck-line` | rules and borders | `border-line` |
| `--deck-letterbox` | the area around the slide on screen | (not printed) |
| `--deck-radius` | card and code corner radius | |
| `--deck-pad-y`, `--deck-pad-x` | slide padding (72px / 88px) | |

Font stacks are exposed as `--deck-font-body/display/mono` and as Tailwind `font-body`, `font-display`, `font-mono`.

## Slides

```html
<section class="slide [middle|center|inverse|bleed]" [data-no-number] [data-footer="…"]>
  …
  <aside class="notes">Speaker notes (HTML allowed). Shown only in presenter view.</aside>
</section>
```

- The slide is a flex column with padding. Children stack from the top; `.push` (margin-top: auto) sends an element to the bottom.
- `middle`: centers vertically. `center`: centers in both directions and centers the text. `inverse`: swaps bg and fg for one slide (the accent stays). `bleed`: no padding, for full-bleed images or layouts.
- `data-no-number`: no number or footer on this slide (covers, dividers). `data-footer`: override the footer text for one slide.
- Any Tailwind class works on the section itself (`class="slide grid grid-cols-2 gap-0 p-0"`). Utilities beat primitives.

## Fragments

`class="fragment"` hides an element until the next "forward" press; `fade-up` adds a small rise, `dim-after` fades it once the next fragment appears. `data-fragment="2"` groups elements into the same step and sets the order (unnumbered fragments go in DOM order). Print and PDF show every fragment.

## Primitives

| class / element | what it is |
|---|---|
| `h1` 84px, `h2` 56px, `h3` 34px | display font, tight leading (looser in RTL) |
| `.eyebrow` | small accent label above a headline (uppercase + tracking in LTR only) |
| `.lead` | large muted intro paragraph, max 46ch |
| `.muted`, `.accent`, `.small` (22px) | text helpers |
| `.push` | margin-top: auto |
| `.stack` | 24px vertical rhythm between children |
| `ul.bullets` | accent square markers, logical indent |
| `ol.steps` | numbered circles; only for real sequences |
| `.cols-2/3/4` | equal grid columns, 44px gap |
| `.split` | two columns, vertically centered, fills the remaining height |
| `.card` | surface panel with radius; `.card h3` is 28px |
| `.stat` | `<div class="stat"><b>42%</b><span>label</span></div>`: 96px number |
| `blockquote.quote` | large display-font quote with an accent rule; `<cite>` inside |
| `pre` / `code` / `kbd` | mono, always LTR; `pre` is a dark block, 21px |
| `table.table` | ruled table; `th.num`/`td.num` align numbers to the end |
| `img.cover-img` | fills its box, `object-fit: cover` (pair with `.slide.bleed`) |
| `figure` / `figcaption` | captioned media |

## Check-mode escape hatches

`--check` flags three things:
- any element extending past the slide edge;
- any `overflow: hidden` box whose content is clipped, vertically or sideways;
- any text or image that runs into the slide number or footer.

Two ways to opt an element out:
- Decorative art meant to bleed off the edge: put it inside an element with `aria-hidden="true"`. That element and everything in it are skipped.
- Anything else intentionally oversized: add `data-allow-overflow` to it or to an ancestor.

## Icons

**Phosphor Icons 2.1.2** is bundled under MIT: 1,512 distinct icons, each in six
styles. Use this library first for common symbols; reserve custom SVG for diagrams,
bespoke artwork, or missing symbols. All styles are available offline.

```html
<!-- Decorative icon beside visible text; inherits its size and color. -->
<h3><i class="ph ph-lightning" aria-hidden="true"></i> Faster delivery</h3>
<!-- Standalone meaningful icon needs an accessible name. -->
<span class="ph-duotone ph-shield-check text-accent text-5xl" role="img" aria-label="Protected"></span>
```

| style class | use |
|---|---|
| `ph` | regular: default for most decks |
| `ph-bold` | stronger strokes for emphasis or a bold theme |
| `ph-fill` | solid silhouettes |
| `ph-duotone` | layered glyphs with a muted secondary area |
| `ph-light`, `ph-thin` | lighter strokes; check readability at presentation size |

Use one style class plus one icon-name class (`ph ph-chart-bar`, for example).
Regular is `ph`, **not** `ph-regular`. Change style with these classes, not CSS
`font-weight`. Prefer one consistent style across a deck, with deliberate exceptions
for emphasis. Use empty `<i>` or `<span>` elements; never put label text inside the
icon element. Size with `font-size` or Tailwind `text-*`, and color with `color` or
`text-accent`. Don't override `font-family` or the `::before`/`::after` contents;
duotone needs both pseudo-elements. Hide decorative icons from assistive technology
with `aria-hidden="true"`; prefer visible labels for meaningful content.

Find exact names locally instead of guessing or reading the whole catalog:

```bash
rg '^\.ph\.ph-.*(chart|graph|users|shield|cloud|database|check|arrow|rocket)' "$KIT/assets/runtime/icons/phosphor/regular/style.css"
```

Useful names: `ph-lightbulb`, `ph-target`, `ph-gear`, `ph-clock`, `ph-currency-dollar`,
`ph-code`, `ph-palette`, `ph-keyboard`, `ph-hand-tap`, `ph-link`, `ph-rocket-launch`.
Every style uses the same name; choose `ph-fill ph-heart`, not `ph ph-heart-fill`.
The [upstream gallery](https://phosphoricons.com/) helps with visual browsing, but
the bundled CSS is authoritative for this pinned version.

The build detects complete style classes in the source and embeds only those
styles' CSS and WOFF2 fonts, plus the license. Regular adds about 268 KiB; using
several styles costs more. No icon configuration, `extraFonts`, download, JavaScript
loader, or external stylesheet is needed. Icons work with `"tailwind": false` too
(use ordinary CSS for size/color). Decks without icon styles include no icon assets.
Put complete style classes in the source; classes constructed only at runtime aren't
detected.

In Persian decks, text stays Vazirmatn. The kit isolates the icon glyphs LTR so
Phosphor's duotone layers align properly; adjacent text stays RTL. Choose directional
icons explicitly (`ph-arrow-left`, for example); glyphs do not automatically mirror.

## Shared SVG (diagrams or custom symbols reused across slides)

- Put one `<svg width="0" height="0" style="position:absolute" aria-hidden="true"><defs>…</defs></svg>` **inside the first slide**. Never between slides: the stage's children must all be slides, because print relies on `.slide:last-child`.
- Elements drawn through `<use>` live in a shadow tree, so descendant selectors like `.art .loop` don't reach them. Style them with presentation attributes, `currentColor`, or CSS custom properties set on the `<use>` element.

## Runtime behaviour (for reference, you don't implement any of it)

- **Navigation keys:**

  | key | action |
  |---|---|
  | → ↓ Space PgDn Enter N | next (same in every deck, RTL included) |
  | ← ↑ Shift+Space PgUp P Backspace | previous |
  | Home / End | first / last slide |
  | digits + Enter | jump to slide (Persian digits work) |

- **Other keys:**

  | key | action |
  |---|---|
  | O | overview grid, arrow keys and Enter inside it |
  | F | fullscreen |
  | S | presenter window with current slide, next slide, notes, timer, clock; synced both ways |
  | B / `.` | black screen |
  | W / `,` | white screen |
  | ? / H | help |
  | Esc | close whatever is open |

  Letter keys match by physical key, so they work on a Persian keyboard layout.
- **Deep links:** `#5` opens slide 5; the hash updates as you move.
- **Touch and mouse:** swipe to navigate; clicks on the outer quarter of the screen go forward or back. Links, buttons and `[data-no-click]` elements are left alone.
- **On-screen chrome:** a progress bar, and a counter that hides with the cursor after 2.5 s idle.
- **Scripting:** `window.deck` exposes `go(i, step)`, `next()`, `prev()`, `index`, `step` and `total` for custom scripts.
