import io
import os
import subprocess
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
from urllib.error import HTTPError, URLError
from email.message import Message
from urllib.request import Request

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "scripts"))
import publish

DECK = '''<!doctype html><html><head>
<meta name="generator" content="html-presentation-kit">
<style>.notes {display:none}</style></head><body>
<section class="slide"><h1>A &amp; B</h1>
<aside class="notes"><p>PRIVATE NOTE<br>nested <b>detail</b></p></aside>
<!--PRIVATE COMMENT--><p class="fragment">Public point</p></section>
<script>const example = '<aside class="notes">not an element</aside>';</script>
</body></html>'''


class PublicHTMLTests(unittest.TestCase):
    def test_notes_comments_removed_and_public_runtime_preserved(self):
        payload, count = publish.prepare_public_html(DECK)
        self.assertEqual(count, 1)
        self.assertNotIn(b"PRIVATE", payload)
        self.assertIn(b"<h1>A &amp; B</h1>", payload)
        self.assertIn(b'<p class="fragment">Public point</p>', payload)
        self.assertIn(b"const example = '<aside", payload)
        self.assertIn(b".notes {display:none}", payload)

    def test_nested_notes_entities_and_void_elements(self):
        text = DECK.replace('<aside class="notes">', '<ASIDE class="other not&#101;s">')
        text = text.replace('nested <b>detail</b>', '<aside>SECRET<img src="x"><hr/></aside>')
        payload, count = publish.prepare_public_html(text)
        self.assertEqual(count, 1)
        self.assertNotIn(b"SECRET", payload)
        self.assertIn(b"Public point", payload)

    def test_literal_ampersands_and_semicolonless_references_are_preserved(self):
        content = 'AT&T, R&D, x=1&y=2, &copy 2026, &#169 and &#xA9;\nAT&amp;T'
        payload, _ = publish.prepare_public_html(DECK.replace('A &amp; B', content))
        self.assertIn(('<h1>' + content + '</h1>').encode(), payload)

    def test_unbalanced_and_self_closing_notes_fail_closed(self):
        for replacement in ('<aside class="notes"/>', '<aside class="notes"><b>'):
            with self.subTest(replacement=replacement), self.assertRaises(publish.PublishError):
                publish.prepare_public_html(DECK.replace('<aside class="notes">', replacement))
        with self.assertRaises(publish.PublishError):
            publish.prepare_public_html(DECK.replace('</aside>\n', '\n'))

    def test_source_and_oversize_rejected(self):
        with self.assertRaisesRegex(publish.PublishError, "built"):
            publish.prepare_public_html('<section class="slide">Source</section>')
        with patch.object(publish, "MAX_BYTES", 20), self.assertRaisesRegex(publish.PublishError, "100 MiB"):
            publish.prepare_public_html(DECK)


class RepositoryTests(unittest.TestCase):
    def info(self, **overrides):
        return {"private": False, "default_branch": "main", "permissions": {"push": True}, **overrides}

    def test_private_unwritable_archived_or_fork_repository_never_mutated(self):
        for values in ({"private": True}, {"permissions": {}}, {"archived": True}, {"fork": True}):
            with self.subTest(values=values), patch.object(publish, "api", return_value=self.info(**values)) as api:
                with self.assertRaises(publish.PublishError):
                    publish.repository("owner/decks", True)
                self.assertEqual(api.call_count, 1)

    def test_unrelated_existing_repository_not_adopted(self):
        with patch.object(publish, "api", side_effect=[self.info(), None, [{"ref": "refs/heads/main"}]]) as api:
            with self.assertRaisesRegex(publish.PublishError, "separate"):
                publish.repository("owner/decks", True)
            self.assertTrue(all(c.args[0] == "GET" for c in api.call_args_list))

    def test_marker_mismatch_refused(self):
        with patch.object(publish, "api", side_effect=[self.info(), {"content": "b3RoZXI="}]):
            with self.assertRaisesRegex(publish.PublishError, "another site"):
                publish.repository("owner/decks", False)

    def test_missing_repository_requires_init(self):
        with patch.object(publish, "api", return_value=None) as api:
            with self.assertRaisesRegex(publish.PublishError, "--init"):
                publish.repository("owner/decks", False)
            self.assertEqual(api.call_count, 1)

    def test_new_repository_is_public_and_initialized(self):
        with patch.object(publish, "api", side_effect=[None, {"login": "owner"}, self.info(), None, [], {}]) as api:
            self.assertEqual(publish.repository("owner/decks", True), "main")
            self.assertIs(api.call_args_list[2].args[2]["private"], False)
            self.assertEqual(api.call_args_list[-1].args[1], "repos/owner/decks/contents/.nojekyll")
            self.assertEqual(publish.decode_content(api.call_args_list[-1].args[2]), publish.MARKER)

    def test_existing_pages_configuration_not_replaced(self):
        with patch.object(publish, "api", return_value={"build_type": "workflow"}) as api:
            with self.assertRaisesRegex(publish.PublishError, "not changed"):
                publish.pages_configuration("owner/decks", "main")
            self.assertEqual(api.call_count, 1)

    def test_real_empty_repository_409_can_be_initialized(self):
        empty = publish.APIError("conflict", 409, "Git Repository is empty.")
        with patch.object(publish, "api", side_effect=[self.info(), None, empty, {}]) as api:
            self.assertEqual(publish.repository("owner/decks", True), "main")
            self.assertEqual(api.call_args.args[0], "PUT")

    def test_unrelated_409_never_treated_as_empty(self):
        with patch.object(publish, "api", side_effect=[self.info(), None, publish.APIError("conflict", 409, "Other conflict")]) as api:
            with self.assertRaises(publish.APIError):
                publish.repository("owner/decks", True)
            self.assertTrue(all(c.args[0] == "GET" for c in api.call_args_list))


class UploadTests(unittest.TestCase):
    """Exercise real commits and rejected concurrent pushes against a bare repo."""

    def run_git(self, args, cwd=None):
        result = subprocess.run(['git', '-c', 'core.hooksPath=/dev/null', '-c', 'commit.gpgsign=false',
                                 '-c', 'user.name=Test', '-c', 'user.email=test@example.com', *args],
                                cwd=cwd, capture_output=True, text=True, check=True)
        return result.stdout.strip()

    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix='kit-publish-test-')
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)
        self.remote = self.root / 'remote.git'
        self.seed = self.root / 'seed'
        self.run_git(['init', '--bare', '--initial-branch=main', str(self.remote)])
        self.run_git(['clone', str(self.remote), str(self.seed)])
        (self.seed / '.nojekyll').write_bytes(publish.MARKER)
        (self.seed / 'kept').mkdir()
        (self.seed / 'kept/index.html').write_text('keep me')
        self.commit_seed('Initialize')
        patcher = patch.object(publish, 'git_remote', return_value=self.remote.as_uri())
        patcher.start()
        self.addCleanup(patcher.stop)

    def commit_seed(self, message):
        self.run_git(['add', '.'], self.seed)
        self.run_git(['commit', '-m', message], self.seed)
        self.run_git(['push', 'origin', 'main'], self.seed)

    def remote_read(self, path):
        return self.run_git(['show', f'main:{path}'], self.remote)

    def head(self):
        return self.run_git(['rev-parse', 'main'], self.remote)

    def test_new_upload_contains_only_one_deck(self):
        publish.upload('owner/decks', 'main', 'demo', b'public', False)
        self.assertEqual(self.remote_read('demo/index.html'), 'public')
        self.assertEqual(self.remote_read('kept/index.html'), 'keep me')
        self.assertEqual(self.run_git(['ls-tree', '-r', '--name-only', 'main'], self.remote).splitlines(),
                         ['.nojekyll', 'demo/index.html', 'kept/index.html'])

    def test_collision_requires_explicit_replace(self):
        head = self.head()
        with self.assertRaisesRegex(publish.PublishError, '--replace'):
            publish.upload('owner/decks', 'main', 'kept', b'new', False)
        self.assertEqual(self.head(), head)
        self.assertEqual(self.remote_read('kept/index.html'), 'keep me')

    def test_identical_upload_creates_no_commit(self):
        head = self.head()
        publish.upload('owner/decks', 'main', 'kept', b'keep me', False)
        self.assertEqual(self.head(), head)

    def test_replace_preserves_other_deck(self):
        publish.upload('owner/decks', 'main', 'demo', b'original', False)
        publish.upload('owner/decks', 'main', 'demo', b'updated', True)
        self.assertEqual(self.remote_read('demo/index.html'), 'updated')
        self.assertEqual(self.remote_read('kept/index.html'), 'keep me')

    def test_concurrent_push_is_rejected_without_retry_or_data_loss(self):
        original_git = publish.git
        pushes = []
        def race(args, cwd=None):
            if args[0] == 'push':
                pushes.append(args)
                (self.seed / 'concurrent.txt').write_text('new remote work')
                self.commit_seed('Concurrent writer')
            return original_git(args, cwd)
        with patch.object(publish, 'git', side_effect=race), self.assertRaisesRegex(publish.PublishError, 'no force push'):
            publish.upload('owner/decks', 'main', 'kept', b'new', True)
        self.assertEqual(len(pushes), 1)
        self.assertEqual(self.remote_read('kept/index.html'), 'keep me')
        self.assertEqual(self.remote_read('concurrent.txt'), 'new remote work')

    def test_symlink_destination_is_rejected(self):
        outside = self.root / 'outside'
        outside.mkdir()
        (outside / 'index.html').write_text('untouched')
        (self.seed / 'demo').symlink_to(outside, target_is_directory=True)
        self.commit_seed('Unexpected symlink')
        with self.assertRaisesRegex(publish.PublishError, 'normal deck directory'):
            publish.upload('owner/decks', 'main', 'demo', b'new', True)
        self.assertEqual((outside / 'index.html').read_text(), 'untouched')

    def test_inherited_git_routing_cannot_touch_callers_index_or_publish_private_files(self):
        caller = self.root / 'caller'
        self.run_git(['init', '--initial-branch=main', str(caller)])
        (caller / 'private.txt').write_text('staged private work')
        self.run_git(['add', 'private.txt'], caller)
        index = caller / '.git/index'
        original_index = index.read_bytes()
        overrides = {'GIT_INDEX_FILE': str(index), 'GIT_DIR': str(caller / '.git'),
                     'GIT_WORK_TREE': str(caller), 'GIT_CONFIG_COUNT': '1',
                     'GIT_CONFIG_KEY_0': 'core.worktree', 'GIT_CONFIG_VALUE_0': str(caller)}
        with patch.dict(os.environ, overrides):
            publish.upload('owner/decks', 'main', 'demo', b'public only', False)
        self.assertEqual(index.read_bytes(), original_index)
        self.assertEqual((caller / 'private.txt').read_text(), 'staged private work')
        self.assertEqual(self.run_git(['diff', '--cached', '--name-only'], caller), 'private.txt')
        self.assertEqual(self.remote_read('demo/index.html'), 'public only')
        self.assertNotIn('private.txt', self.run_git(['ls-tree', '-r', '--name-only', 'main'], self.remote))


class VerificationTests(unittest.TestCase):
    def response(self, body, content_type="text/html"):
        response = io.BytesIO(body)
        response.headers = Message()
        response.headers["Content-Type"] = content_type
        response.geturl = lambda: "https://owner.github.io/decks/demo/"
        return response

    def test_verifies_anonymous_exact_html_after_stale_response(self):
        with patch.object(publish, "urlopen", side_effect=[self.response(b"old"), self.response(b"new")]) as opening, patch.object(publish.time, "sleep"):
            publish.verify_url("https://owner.github.io/decks/demo/", b"new", 30)
            self.assertEqual(opening.call_count, 2)
            request = opening.call_args.args[0]
            self.assertNotIn("Authorization", request.headers)

    def test_failed_or_wrong_content_response_does_not_claim_success(self):
        for response in (URLError("offline"), self.response(b"wrong"), self.response(b"new", "text/plain")):
            with self.subTest(response=response), patch.object(publish, "urlopen", side_effect=[response]), patch.object(publish.time, "monotonic", side_effect=[0, 0, 0, 30, 31]), patch.object(publish.time, "sleep"):
                with self.assertRaisesRegex(publish.PublishError, "verification timed out"):
                    publish.verify_url("https://owner.github.io/decks/demo/", b"new", 20)


class PipelineTests(unittest.TestCase):
    def test_invalid_target_or_failed_check_never_calls_github(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "deck.html"
            path.write_text(DECK)
            with patch.object(publish, "api") as api:
                for repo, slug in (("owner/repo/extra", "demo"), ("owner/repo", "../secret")):
                    with self.assertRaises(publish.PublishError):
                        publish.publish(path, repo, slug)
                with patch.object(publish.build, "run_check", return_value={"issues": [{"overflow": 10}], "fonts": {}}):
                    with self.assertRaisesRegex(publish.PublishError, "failed"):
                        publish.publish(path, "owner/repo", "demo")
                api.assert_not_called()
            self.assertEqual(path.read_text(), DECK)

    def test_unauthenticated_cli_failure(self):
        result = type("Result", (), {"returncode": 1, "stdout": "", "stderr": "To get started, run gh auth login"})()
        with patch.object(publish.subprocess, "run", return_value=result):
            publish.credentials.cache_clear()
            with self.assertRaisesRegex(publish.PublishError, "gh auth login"):
                publish.api("GET", "user")


class TransportTests(unittest.TestCase):
    def test_authenticated_redirects_never_forward_the_token(self):
        request = Request('https://api.github.com/repos/owner/decks', headers={'Authorization': 'Bearer fake-token'})
        for target in ('https://other.example/', 'http://api.github.com/', 'https://api.github.com/renamed'):
            with self.subTest(target=target), self.assertRaisesRegex(publish.PublishError, 'redirects are refused'):
                publish.NoAPIRedirects().redirect_request(request, None, 302, 'Found', {}, target)

    def test_http_errors_preserve_empty_repository_detail_and_deny_unauthorized(self):
        for code, message in ((409, 'Git Repository is empty.'), (403, 'Resource not accessible')):
            error = HTTPError('https://api.github.com/test', code, 'error', {}, io.BytesIO(('{"message":"'+message+'"}').encode()))
            with patch.object(publish, "credentials", return_value="test-token"), patch.object(publish, "api_urlopen", side_effect=error) as opening:
                with self.assertRaises(publish.APIError) as caught:
                    publish.api("GET", "user", missing_ok=True)
                self.assertEqual(caught.exception.status, code)
                self.assertEqual(caught.exception.github_message, message)
                self.assertEqual(opening.call_count, 1)

    def test_only_read_connection_failures_are_retried(self):
        for method, expected_calls in (("GET", 2), ("PUT", 1)):
            with patch.object(publish, "credentials", return_value="test-token"), patch.object(publish, "api_urlopen", side_effect=URLError("offline")) as opening:
                with self.assertRaises(publish.PublishError):
                    publish.api(method, "repos/owner/decks")
                self.assertEqual(opening.call_count, expected_calls)

    def test_missing_is_allowed_only_for_404(self):
        error = HTTPError('https://api.github.com/test', 404, 'Not Found', {}, io.BytesIO(b'{}'))
        with patch.object(publish, "credentials", return_value="test-token"), patch.object(publish, "api_urlopen", side_effect=error):
            self.assertIsNone(publish.api("GET", "repos/owner/decks", missing_ok=True))


if __name__ == "__main__":
    unittest.main()
