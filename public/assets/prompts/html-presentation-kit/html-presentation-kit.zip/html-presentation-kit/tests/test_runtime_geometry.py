import json
import subprocess
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
BUILD = ROOT / "scripts" / "build.py"


def test_broad_theme_slide_position_does_not_break_navigation(tmp_path):
    source = tmp_path / "geometry.slides.html"
    source.write_text(
        """<script type=\"application/json\" id=\"deck-config\">{\"title\":\"geometry\"}</script>
<style>.slide { position: relative; }</style>
<section class=\"slide\"><h1>One</h1></section>
<section class=\"slide\"><h1>Two</h1></section>
""",
        encoding="utf-8",
    )
    out = tmp_path / "geometry.html"
    subprocess.run(
        ["python3", str(BUILD), str(source), "-o", str(out), "--check"],
        check=True,
        capture_output=True,
        text=True,
    )

    # The runtime check is intentionally the assertion: if the engine loses
    # its stacking geometry, build.py must fail instead of producing a blank
    # deck after the first slide.
    assert "check ok: 2 slides, no overflow" in subprocess.run(
        ["python3", str(BUILD), str(source), "-o", str(out), "--check"],
        check=True,
        capture_output=True,
        text=True,
    ).stdout
