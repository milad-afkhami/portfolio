# Vendored third-party files

| file | project | version | license |
|---|---|---|---|
| `tailwind.browser.js` | [@tailwindcss/browser](https://tailwindcss.com) | 4.3.3 | MIT |
| `icons/phosphor/*/style.css`, `icons/phosphor/*/*.woff2` | [@phosphor-icons/web](https://github.com/phosphor-icons/web) | 2.1.2 | MIT; full text in `icons/phosphor/LICENSE` |
| `fonts/nunito-*.woff2` | Nunito (via @fontsource-variable) | variable | SIL OFL 1.1 |
| `fonts/lexend-*.woff2` | Lexend (via @fontsource-variable) | variable | SIL OFL 1.1 |
| `fonts/lora-*.woff2` | Lora (via @fontsource-variable) | variable | SIL OFL 1.1 |
| `fonts/vazirmatn-*.woff2` | Vazirmatn (via @fontsource-variable) | variable | SIL OFL 1.1 |
| `fonts/jetbrains-mono-*.woff2` | JetBrains Mono (via @fontsource-variable) | variable | SIL OFL 1.1 |

These are runtime assets that get embedded into each built deck, not skills. To update Tailwind:
`curl -fL -o tailwind.browser.js https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4/dist/index.global.js`

Phosphor assets are unmodified files from the published `@phosphor-icons/web@2.1.2`
package: `src/{regular,thin,light,bold,fill,duotone}/style.css`, the corresponding
WOFF2 in each directory, and `LICENSE`. Source archive:
`https://registry.npmjs.org/@phosphor-icons/web/-/web-2.1.2.tgz`.
Update CSS, fonts and license together from one pinned release. The build replaces
each used style's font-face with embedded WOFF2, includes the full MIT notice, and
adds an LTR inline-block wrapper rule for correct duotone layering in RTL decks.
The regular CSS is the local searchable icon-name catalog.
