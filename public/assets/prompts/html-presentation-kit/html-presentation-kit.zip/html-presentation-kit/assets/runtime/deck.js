/* html-presentation-kit runtime. Inlined into every deck by scripts/build.py.
 *
 * Reads window.DECK_CONFIG (written by the build) and drives the slides in
 * .deck-stage: fit-to-window scaling, keyboard/touch/click navigation,
 * fragments, #n deep links, overview grid, presenter window, black/white
 * curtain, help overlay, and a ?check mode that reports overflowing content.
 *
 * Like PowerPoint, the presenting tool itself is always English and LTR: help,
 * presenter view, overview, counters, slide numbers and navigation keys behave
 * the same in every deck. Only the slide content follows the deck's language.
 */
(function () {
  'use strict';

  var W = 1280, H = 720;
  var cfg = window.DECK_CONFIG || {};
  var root = document.documentElement;
  var contentDir = root.getAttribute('dir') || cfg.dir || 'ltr';
  var params = new URLSearchParams(location.search);
  var isPresenter = params.has('presenter');
  var isCheck = params.has('check');

  var t = {
    help: 'Keyboard shortcuts', next: 'Next', prev: 'Previous', firstLast: 'First / last slide',
    jump: 'Go to slide (type the number, then Enter)', overview: 'Overview of all slides',
    fullscreen: 'Fullscreen', presenter: 'Presenter view (notes, next slide, timer)',
    curtain: 'Black / white screen', helpKey: 'Show or hide this help', close: 'Close overlay',
    print: 'Print or save as PDF (Chrome, one slide per page)',
    swipe: 'On touch screens, swipe to move. Click near the edges to go forward or back.',
    nextSlide: 'Next slide', notes: 'Notes', noNotes: 'No notes for this slide.',
    end: 'End of deck', timerHint: 'Click the timer to pause, double-click to reset.'
  };

  var stage = document.querySelector('.deck-stage');
  var viewport = document.querySelector('.deck-viewport');
  if (!stage) return;
  var slides = Array.prototype.slice.call(stage.children).filter(function (el) {
    return el.classList && el.classList.contains('slide');
  });
  var total = slides.length;
  if (!total) return;

  var index = 0, step = 0;
  function num(n) { return String(n); }
  var groups = slides.map(fragmentGroups);
  slides.forEach(function (sl) { if (!sl.hasAttribute('dir')) sl.setAttribute('dir', contentDir); });

  function fragmentGroups(slide) {
    var frags = Array.prototype.slice.call(slide.querySelectorAll('.fragment'));
    var byKey = {}, order = [];
    frags.forEach(function (el, i) {
      var k = el.hasAttribute('data-fragment') ? 'i' + parseFloat(el.getAttribute('data-fragment')) : 'd' + i;
      var n = el.hasAttribute('data-fragment') ? parseFloat(el.getAttribute('data-fragment')) : null;
      if (!byKey[k]) { byKey[k] = { n: n, pos: i, els: [] }; order.push(byKey[k]); }
      byKey[k].els.push(el);
    });
    order.sort(function (a, b) {
      var an = a.n === null ? a.pos : a.n, bn = b.n === null ? b.pos : b.n;
      return an - bn || a.pos - b.pos;
    });
    return order.map(function (g) { return g.els; });
  }

  /* ---------- per-slide chrome: numbers and footer (these print) ---------- */
  slides.forEach(function (slide, i) {
    if (slide.hasAttribute('data-no-number')) return;
    if (cfg.slideNumbers !== false) {
      var numEl = document.createElement('div');
      numEl.className = 'slide-number';
      numEl.textContent = num(i + 1);
      slide.appendChild(numEl);
    }
    var footText = slide.getAttribute('data-footer') || cfg.footer;
    if (footText) {
      var foot = document.createElement('div');
      foot.className = 'slide-footer';
      foot.textContent = footText;
      slide.appendChild(foot);
    }
  });

  /* ---------- UI elements ---------- */
  function el(tag, cls, parent) {
    var e = document.createElement(tag);
    if (cls) e.className = cls;
    if (!parent) { e.setAttribute('dir', 'ltr'); e.setAttribute('lang', 'en'); }
    (parent || document.body).appendChild(e);
    return e;
  }
  var progress = el('div', 'deck-ui deck-progress');
  var progressBar = el('i', '', progress);
  var counter = el('div', 'deck-ui deck-counter');
  var jumpBox = el('div', 'deck-ui deck-jump');
  var curtain = el('div', 'deck-ui deck-curtain');
  var help = el('div', 'deck-ui deck-help');
  var overview = el('div', 'deck-ui deck-overview');
  var overviewGrid = el('div', 'deck-overview-grid', overview);

  var nextKeys = '→', prevKeys = '←';
  function row(keys, text) {
    return '<dt>' + keys.map(function (k) { return '<kbd>' + k + '</kbd>'; }).join('') + '</dt><dd>' + text + '</dd>';
  }
  help.innerHTML = '<div class="deck-help-card" role="dialog" aria-modal="true"><h2>' + t.help + '</h2><dl>' +
    row([nextKeys, '↓', 'Space', 'PgDn'], t.next) +
    row([prevKeys, '↑', 'Shift+Space', 'PgUp'], t.prev) +
    row(['Home', 'End'], t.firstLast) +
    row(['1…9', 'Enter'], t.jump) +
    row(['O'], t.overview) +
    row(['F'], t.fullscreen) +
    row(['S'], t.presenter) +
    row(['B', 'W'], t.curtain) +
    row(['Ctrl+P'], t.print) +
    row(['?', 'H'], t.helpKey) +
    row(['Esc'], t.close) +
    '</dl><p>' + t.swipe + '</p></div>';
  help.addEventListener('click', function (e) { if (e.target === help) toggleHelp(false); });

  /* ---------- scaling ---------- */
  var region = viewport;
  function fit() {
    if (isCheck) { stage.style.setProperty('--deck-scale', '1'); return; }
    var r = region.getBoundingClientRect();
    var s = Math.min(r.width / W, r.height / H);
    root.style.setProperty('--deck-scale', String(s));
    root.style.setProperty('--deck-cx', (r.left + r.width / 2) + 'px');
    root.style.setProperty('--deck-cy', (r.top + r.height / 2) + 'px');
    if (presenter) presenter.fitNext();
    if (overview.classList.contains('is-on')) scaleThumbs();
  }
  window.addEventListener('resize', fit);

  /* ---------- navigation ---------- */
  function go(i, s, opts) {
    opts = opts || {};
    i = Math.max(0, Math.min(total - 1, i | 0));
    var g = groups[i];
    if (s === 'all') s = g.length;
    s = Math.max(0, Math.min(g.length, s | 0));
    if (i !== index) slides[index].classList.remove('is-active');
    index = i; step = s;
    slides[i].classList.add('is-active');
    slides.forEach(function (sl, j) { sl.setAttribute('aria-hidden', j === i ? 'false' : 'true'); });
    g.forEach(function (els, k) {
      els.forEach(function (e) {
        e.classList.toggle('is-visible', k < s);
        e.classList.toggle('is-past', k < s - 1);
      });
    });
    progressBar.style.width = (total > 1 ? (i / (total - 1)) * 100 : 100) + '%';
    counter.textContent = num(i + 1) + ' / ' + num(total);
    var hash = '#' + (i + 1);
    if (location.hash !== hash) history.replaceState(null, '', hash);
    if (presenter) presenter.update();
    if (!opts.silent) send({ type: 'deck-go', index: i, step: s });
  }
  function next() {
    if (step < groups[index].length) go(index, step + 1);
    else if (index < total - 1) go(index + 1, 0);
  }
  function prev() {
    if (step > 0) go(index, step - 1);
    else if (index > 0) go(index - 1, 'all');
  }
  function fromHash() {
    var m = /^#\/?(\d+)/.exec(location.hash);
    return m ? parseInt(m[1], 10) - 1 : 0;
  }
  window.addEventListener('hashchange', function () {
    var i = fromHash();
    if (i !== index) go(i, 0);
  });

  /* ---------- sync between audience and presenter windows ---------- */
  var channel = null;
  try { channel = new BroadcastChannel('deck:' + location.pathname); } catch (e) { /* unsupported */ }
  var peers = [];
  if (window.opener && isPresenter) peers.push(window.opener);
  function send(msg) {
    msg.src = isPresenter ? 'presenter' : 'audience';
    peers.forEach(function (p) { try { if (!p.closed) p.postMessage(msg, '*'); } catch (e) { /* gone */ } });
    if (channel) channel.postMessage(msg);
  }
  var lastSeen = '';
  function receive(msg) {
    if (!msg || typeof msg !== 'object' || msg.src === (isPresenter ? 'presenter' : 'audience')) return;
    var key = JSON.stringify(msg);
    if (key === lastSeen) return;           // same message via postMessage and channel
    lastSeen = key;
    setTimeout(function () { if (lastSeen === key) lastSeen = ''; }, 50);
    if (msg.type === 'deck-go') go(msg.index, msg.step, { silent: true });
    else if (msg.type === 'deck-curtain') setCurtain(msg.mode, true);
    else if (msg.type === 'deck-hello' && !isPresenter) send({ type: 'deck-go', index: index, step: step });
  }
  window.addEventListener('message', function (e) { receive(e.data); });
  if (channel) channel.onmessage = function (e) { receive(e.data); };

  /* ---------- curtain ---------- */
  var curtainMode = '';
  function setCurtain(mode, silent) {
    curtainMode = curtainMode === mode ? '' : mode;
    curtain.className = 'deck-ui deck-curtain' + (curtainMode ? ' is-' + curtainMode : '');
    if (isPresenter) curtain.className = 'deck-ui deck-curtain'; // presenter keeps seeing slides
    if (!silent) send({ type: 'deck-curtain', mode: mode });
  }

  /* ---------- help ---------- */
  function toggleHelp(force) {
    var on = force === undefined ? !help.classList.contains('is-on') : force;
    help.classList.toggle('is-on', on);
  }

  /* ---------- overview ---------- */
  var selected = 0;
  function cloneSlide(slide) {
    var c = slide.cloneNode(true);
    c.removeAttribute('id');
    c.classList.remove('is-active');
    c.setAttribute('aria-hidden', 'true');
    Array.prototype.forEach.call(c.querySelectorAll('[id]'), function (n) { n.removeAttribute('id'); });
    return c;
  }
  function buildOverview() {
    overviewGrid.innerHTML = '';
    slides.forEach(function (slide, i) {
      var th = el('div', 'deck-thumb', overviewGrid);
      th.appendChild(cloneSlide(slide));
      var n = el('span', 'deck-thumb-num', th);
      n.textContent = num(i + 1);
      th.addEventListener('click', function () { toggleOverview(false); go(i, 0); });
    });
  }
  function scaleThumbs() {
    Array.prototype.forEach.call(overviewGrid.children, function (th) {
      var s = th.clientWidth / W;
      th.firstChild.style.transform = 'scale(' + s + ')';
    });
  }
  function markSelected() {
    Array.prototype.forEach.call(overviewGrid.children, function (th, i) {
      th.classList.toggle('is-current', i === index);
      th.classList.toggle('is-selected', i === selected && i !== index);
    });
    var cur = overviewGrid.children[selected];
    if (cur && cur.scrollIntoView) cur.scrollIntoView({ block: 'nearest' });
  }
  function toggleOverview(force) {
    var on = force === undefined ? !overview.classList.contains('is-on') : force;
    if (on && !overviewGrid.children.length) buildOverview();
    overview.classList.toggle('is-on', on);
    if (on) { selected = index; scaleThumbs(); markSelected(); }
  }
  function overviewCols() {
    var kids = overviewGrid.children, top = kids[0] && kids[0].offsetTop, n = 0;
    while (n < kids.length && kids[n].offsetTop === top) n++;
    return Math.max(1, n);
  }

  /* ---------- fullscreen ---------- */
  function toggleFullscreen() {
    if (document.fullscreenElement) document.exitFullscreen();
    else if (root.requestFullscreen) root.requestFullscreen();
  }

  /* ---------- presenter ---------- */
  var presenterWin = null;
  function openPresenter() {
    if (isPresenter) return;
    var url = new URL(location.href);
    url.searchParams.set('presenter', '1');
    url.hash = String(index + 1);
    presenterWin = window.open(url.toString(), 'deck-presenter', 'width=1280,height=800');
    if (presenterWin) peers = [presenterWin];
  }

  var presenter = null;
  if (isPresenter) {
    document.body.classList.add('deck-presenter-mode');
    var p = el('div', 'deck-ui deck-presenter');
    p.innerHTML =
      '<div class="deck-presenter-bar"><span class="deck-timer" title="' + t.timerHint + '">00:00</span>' +
      '<span class="deck-clock"></span><span class="deck-pcount"></span><span class="deck-ptitle"></span></div>' +
      '<div class="deck-presenter-current"></div>' +
      '<div class="deck-presenter-side"><div class="deck-presenter-label">' + t.nextSlide + '</div>' +
      '<div class="deck-presenter-next" data-end="' + t.end + '"></div>' +
      '<div class="deck-presenter-label">' + t.notes + '</div>' +
      '<div class="deck-presenter-notes" data-empty="' + t.noNotes + '"></div></div>';
    document.title = '[Presenter] ' + document.title;
    region = p.querySelector('.deck-presenter-current');
    var timerEl = p.querySelector('.deck-timer'), clockEl = p.querySelector('.deck-clock');
    var nextEl = p.querySelector('.deck-presenter-next'), notesEl = p.querySelector('.deck-presenter-notes');
    p.querySelector('.deck-ptitle').textContent = cfg.title || '';
    var started = Date.now(), pausedAt = 0;
    timerEl.addEventListener('click', function () {
      if (pausedAt) { started += Date.now() - pausedAt; pausedAt = 0; } else { pausedAt = Date.now(); }
      timerEl.classList.toggle('is-paused', !!pausedAt);
    });
    timerEl.addEventListener('dblclick', function () { started = Date.now(); pausedAt = 0; timerEl.classList.remove('is-paused'); });
    var pad = function (n) { return (n < 10 ? '0' : '') + n; };
    setInterval(function () {
      var ms = (pausedAt || Date.now()) - started, sec = Math.floor(ms / 1000);
      var h = Math.floor(sec / 3600), m = Math.floor(sec / 60) % 60;
      timerEl.textContent = (h ? h + ':' : '') + pad(m) + ':' + pad(sec % 60);
      var d = new Date();
      clockEl.textContent = pad(d.getHours()) + ':' + pad(d.getMinutes());
    }, 500);
    presenter = {
      update: function () {
        p.querySelector('.deck-pcount').textContent = num(index + 1) + ' / ' + num(total);
        nextEl.innerHTML = '';
        // "next" means the next thing the audience will see: a fragment or the next slide
        var target = step < groups[index].length ? index : index + 1;
        nextEl.classList.toggle('is-end', target >= total);
        if (target < total) {
          // the preview shows every fragment of the target slide at once
          var c = cloneSlide(slides[target]);
          nextEl.appendChild(c);
          presenter.fitNext();
        }
        var notes = slides[index].querySelector('.notes');
        notesEl.innerHTML = notes ? notes.innerHTML : '';
        notesEl.setAttribute('dir', notes && notes.textContent.trim() ? contentDir : 'ltr');   // notes are deck content
      },
      fitNext: function () {
        var c = nextEl.firstChild;
        if (c) c.style.transform = 'scale(' + (nextEl.clientWidth / W) + ')';
      }
    };
  }

  /* ---------- keyboard ---------- */
  var jumpBuf = '', jumpTimer = 0;
  var FA_DIGITS = '۰۱۲۳۴۵۶۷۸۹', AR_DIGITS = '٠١٢٣٤٥٦٧٨٩';
  function digitOf(e) {
    if (/^Digit\d$|^Numpad\d$/.test(e.code)) return e.code.slice(-1);
    var k = e.key;
    if (/^\d$/.test(k)) return k;
    var i = FA_DIGITS.indexOf(k); if (i >= 0) return String(i);
    i = AR_DIGITS.indexOf(k); if (i >= 0) return String(i);
    return null;
  }
  function setJump(v) {
    jumpBuf = v;
    jumpBox.textContent = v;
    jumpBox.classList.toggle('is-on', !!v);
    clearTimeout(jumpTimer);
    if (v) jumpTimer = setTimeout(function () { setJump(''); }, 2500);
  }

  document.addEventListener('keydown', function (e) {
    if (e.ctrlKey || e.metaKey || e.altKey) return;       // leave Ctrl+P, browser shortcuts alone
    var tg = e.target;
    if (tg && (tg.isContentEditable || /^(INPUT|TEXTAREA|SELECT)$/.test(tg.tagName))) return;

    var code = e.code, key = e.key;
    var helpOn = help.classList.contains('is-on');
    var ovOn = overview.classList.contains('is-on');

    if (code === 'Escape') {
      if (jumpBuf) setJump('');
      else if (helpOn) toggleHelp(false);
      else if (ovOn) toggleOverview(false);
      else if (curtainMode) setCurtain(curtainMode);
      e.preventDefault();
      return;
    }
    if ((code === 'Slash' && e.shiftKey) || key === '?' || key === '؟' || code === 'KeyH') { toggleHelp(); e.preventDefault(); return; }
    if (helpOn) return;

    var d = digitOf(e);
    if (d !== null && !ovOn) { setJump((jumpBuf + d).slice(0, 4)); e.preventDefault(); return; }
    if (code === 'Backspace' && jumpBuf) { setJump(jumpBuf.slice(0, -1)); e.preventDefault(); return; }
    if ((code === 'Enter' || code === 'NumpadEnter') && jumpBuf) {
      var n = parseInt(jumpBuf, 10); setJump('');
      if (n >= 1) go(Math.min(n, total) - 1, 0);
      e.preventDefault();
      return;
    }

    var fwd = 'ArrowRight', back = 'ArrowLeft';

    if (ovOn) {
      var cols = overviewCols();
      if (code === fwd) selected = Math.min(total - 1, selected + 1);
      else if (code === back) selected = Math.max(0, selected - 1);
      else if (code === 'ArrowDown') selected = Math.min(total - 1, selected + cols);
      else if (code === 'ArrowUp') selected = Math.max(0, selected - cols);
      else if (code === 'Home') selected = 0;
      else if (code === 'End') selected = total - 1;
      else if (code === 'Enter' || code === 'Space') { toggleOverview(false); go(selected, 0); e.preventDefault(); return; }
      else if (code === 'KeyO') { toggleOverview(false); e.preventDefault(); return; }
      else return;
      markSelected();
      e.preventDefault();
      return;
    }

    if (code === fwd || code === 'ArrowDown' || code === 'PageDown' || (code === 'Space' && !e.shiftKey) || code === 'Enter' || code === 'NumpadEnter' || code === 'KeyN') next();
    else if (code === back || code === 'ArrowUp' || code === 'PageUp' || (code === 'Space' && e.shiftKey) || code === 'KeyP' || code === 'Backspace') prev();
    else if (code === 'Home') go(0, 0);
    else if (code === 'End') go(total - 1, 'all');
    else if (code === 'KeyO') toggleOverview();
    else if (code === 'KeyF') toggleFullscreen();
    else if (code === 'KeyS') openPresenter();
    else if (code === 'KeyB' || code === 'Period') setCurtain('black');
    else if (code === 'KeyW' || code === 'Comma') setCurtain('white');
    else return;
    e.preventDefault();
  });

  /* ---------- touch swipe + edge clicks ---------- */
  var sx = 0, sy = 0, touching = false;
  viewport.addEventListener('pointerdown', function (e) {
    if (e.pointerType === 'mouse') return;
    touching = true; sx = e.clientX; sy = e.clientY;
  });
  viewport.addEventListener('pointerup', function (e) {
    if (!touching) return;
    touching = false;
    var dx = e.clientX - sx, dy = e.clientY - sy;
    if (Math.abs(dx) < 50 || Math.abs(dx) < Math.abs(dy)) return;
    var forward = dx < 0;                          // swipe left = next, as in any slide app
    if (forward) next(); else prev();
  });
  viewport.addEventListener('click', function (e) {
    if (e.target.closest('a, button, input, textarea, select, label, summary, video, audio, [data-no-click]')) return;
    var sel = window.getSelection && window.getSelection();
    if (sel && String(sel).length) return;
    var r = viewport.getBoundingClientRect(), x = (e.clientX - r.left) / r.width;
    var atEnd = x > .75, atStart = x < .25;
    if (atEnd) next(); else if (atStart) prev();
  });

  /* ---------- idle cursor ---------- */
  var idleTimer = 0;
  function wake() {
    document.body.classList.remove('deck-idle');
    clearTimeout(idleTimer);
    idleTimer = setTimeout(function () { document.body.classList.add('deck-idle'); }, 2500);
  }
  document.addEventListener('mousemove', wake);
  wake();

  /* ---------- check mode: report content that spills outside its slide ---------- */
  function runCheck() {
    var report = { slides: total, issues: [], fonts: {} };
    (cfg.fontFamilies || []).forEach(function (f) {
      report.fonts[f] = document.fonts ? document.fonts.check('16px "' + f + '"') : null;
    });
    function hasOwnContent(n) {
      if (/^(IMG|SVG|CANVAS|VIDEO|PRE|svg)$/.test(n.tagName)) return true;
      for (var c = n.firstChild; c; c = c.nextSibling) if (c.nodeType === 3 && c.data.trim()) return true;
      return false;
    }
    function overlaps(a, b) {
      return a.left < b.right - 1 && b.left < a.right - 1 && a.top < b.bottom - 1 && b.top < a.bottom - 1;
    }
    slides.forEach(function (slide, i) {
      var sr = slide.getBoundingClientRect();
      var seen = 0;
      var chrome = Array.prototype.slice.call(slide.querySelectorAll(':scope > .slide-number, :scope > .slide-footer'))
        .map(function (c) { return c.getBoundingClientRect(); })
        .filter(function (r) { return r.width && r.height; });
      Array.prototype.forEach.call(slide.querySelectorAll('*'), function (n) {
        if (seen >= 5) return;
        if (n.closest('.notes, [data-allow-overflow]') || n.classList.contains('slide-number') || n.classList.contains('slide-footer')) return;
        var r = n.getBoundingClientRect();
        if (!r.width && !r.height) return;
        if (n.closest('[aria-hidden="true"]:not(.slide)')) return;       // decorative art may bleed
        var cs = getComputedStyle(n);
        var out = r.right > sr.right + 2 || r.bottom > sr.bottom + 2 || r.left < sr.left - 2 || r.top < sr.top - 2;
        var hid = cs.overflow === 'hidden' || cs.overflowX === 'hidden' || cs.overflowY === 'hidden' || cs.overflow === 'clip';
        var clipped = hid && n.tagName !== 'PRE' && (n.scrollHeight > n.clientHeight + 2 || n.scrollWidth > n.clientWidth + 2);
        var hitsChrome = !out && !clipped && hasOwnContent(n) && chrome.some(function (c) { return overlaps(r, c); });
        if (out || clipped || hitsChrome) {
          seen++;
          report.issues.push({
            slide: i + 1,
            element: n.tagName.toLowerCase() + (n.className && typeof n.className === 'string' ? '.' + n.className.trim().split(/\s+/).join('.') : ''),
            text: (n.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 60),
            problem: out ? 'extends past the slide edge' : clipped ? 'content clipped inside its box' : 'runs into the slide number / footer',
            overflowPx: Math.round(out ? Math.max(r.right - sr.right, r.bottom - sr.bottom, sr.left - r.left, sr.top - r.top)
              : clipped ? Math.max(n.scrollHeight - n.clientHeight, n.scrollWidth - n.clientWidth)
              : Math.max.apply(null, chrome.map(function (c) { return r.bottom - c.top; })))
          });
        }
      });
      var pre = slide.querySelectorAll('pre');
      Array.prototype.forEach.call(pre, function (p) {
        if (p.scrollWidth > p.clientWidth + 2 || p.scrollHeight > p.clientHeight + 2) {
          report.issues.push({ slide: i + 1, element: 'pre', text: p.textContent.trim().slice(0, 60), problem: 'code block is cut off', overflowPx: Math.round(Math.max(p.scrollWidth - p.clientWidth, p.scrollHeight - p.clientHeight)) });
        }
      });
    });
    var out = document.createElement('pre');
    out.id = 'deck-check-result';
    out.style.display = 'none';
    out.textContent = JSON.stringify(report);
    document.body.appendChild(out);
  }

  /* ---------- start ---------- */
  root.classList.add('deck-ready');
  go(fromHash(), 0, { silent: true });
  fit();
  // transitions only after the first paint, so opening #5 doesn't fade in from slide 1
  requestAnimationFrame(function () { requestAnimationFrame(function () { root.classList.add('deck-anim'); }); });
  if (isPresenter) send({ type: 'deck-hello' });
  if (isCheck) {
    var ready = document.fonts && document.fonts.ready ? document.fonts.ready : Promise.resolve();
    ready.then(function () { setTimeout(runCheck, 600); });
  }
  window.deck = { go: go, next: next, prev: prev, get index() { return index; }, get step() { return step; }, total: total };
})();
