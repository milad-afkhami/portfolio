// Chrome Bridge — background service worker.
// Auto-connects to the local MCP server's WebSocket and executes commands.
// Design rule: NEVER activate/raise a tab or window. Every op targets a tabId
// and runs in the background so it never steals your focus.

const PORT = 9223;
const URL = `ws://127.0.0.1:${PORT}`;
let ws = null;
let connected = false;
let connectedSince = null;
let lastAction = null;
let lastActionAt = null;
let commandCount = 0;
// Restore counters so the popup survives service-worker suspension.
try {
  chrome.storage.local.get(['commandCount', 'lastAction', 'lastActionAt'], (d) => {
    if (typeof d.commandCount === 'number') commandCount = d.commandCount;
    if (d.lastAction) { lastAction = d.lastAction; lastActionAt = d.lastActionAt; }
  });
} catch {}

function connect() {
  try { ws = new WebSocket(URL); } catch { scheduleReconnect(); return; }

  ws.onopen = () => { connected = true; connectedSince = Date.now(); try { ws.send(JSON.stringify({ hello: 'ext' })); } catch {} console.log('[chrome-bridge] connected'); };
  ws.onclose = () => { connected = false; connectedSince = null; scheduleReconnect(); };
  ws.onerror = () => { try { ws.close(); } catch {} };

  ws.onmessage = async (ev) => {
    let msg;
    try { msg = JSON.parse(ev.data); } catch { return; }
    const { id, action, params } = msg;
    try {
      const result = await handle(action, params || {});
      ws.send(JSON.stringify({ id, result }));
    } catch (e) {
      ws.send(JSON.stringify({ id, error: String((e && e.message) || e) }));
    }
  };
}

let reconnectTimer = null;
function scheduleReconnect() {
  if (reconnectTimer) return;
  reconnectTimer = setTimeout(() => { reconnectTimer = null; connect(); }, 1500);
}

connect();

// Reconnect triggers that survive MV3 service-worker suspension.
// An alarm re-wakes the (possibly suspended) worker to retry; the top-level
// connect() above runs again each time the worker is revived by any event.
chrome.runtime.onStartup.addListener(connect);
chrome.runtime.onInstalled.addListener(connect);
try { chrome.alarms.create('cb-keepalive', { periodInMinutes: 0.5 }); } catch {}
chrome.alarms.onAlarm.addListener((a) => {
  if (a.name === 'cb-keepalive' && (!ws || ws.readyState !== WebSocket.OPEN)) connect();
});
// While the worker is alive, retry quickly too.
setInterval(() => {
  if (!ws || ws.readyState === WebSocket.CLOSED) connect();
}, 5000);

// Design rule: tab-targeting tools NEVER fall back to your focused tab. A call
// must name its tabId — from list_tabs (drive an existing tab) or open_tab (start
// fresh). This makes it impossible for a session to hijack the page you're on.
function requireTab(p) {
  if (p.tabId == null) {
    throw new Error(
      'tabId is required — call list_tabs to pick an existing tab, or open_tab to ' +
      'start a fresh one. This bridge never falls back to your focused tab.'
    );
  }
  return p.tabId;
}

// ---- network capture (webRequest; no banner, no response bodies) ----
let capturing = false;
let captureTabId = null;
let captured = [];
const inflight = new Map();
// Always-on (independent of `capturing`) per-tab in-flight request tracking, so
// wait_for {networkIdle:true} can tell when a page has settled without a capture.
const netInflight = new Map(); // tabId -> Set<requestId>
const netLastActivity = new Map(); // tabId -> timestamp of last start/end
function netTrackStart(d) {
  if (d.tabId == null || d.tabId < 0) return;
  let set = netInflight.get(d.tabId);
  if (!set) { set = new Set(); netInflight.set(d.tabId, set); }
  set.add(d.requestId);
  netLastActivity.set(d.tabId, Date.now());
}
function netTrackEnd(d) {
  if (d.tabId == null || d.tabId < 0) return;
  const set = netInflight.get(d.tabId);
  if (set) { set.delete(d.requestId); if (set.size === 0) netInflight.delete(d.tabId); }
  netLastActivity.set(d.tabId, Date.now());
}
function netStart(d) {
  netTrackStart(d);
  if (!capturing || (captureTabId != null && d.tabId !== captureTabId)) return;
  inflight.set(d.requestId, { url: d.url, method: d.method, type: d.type, tabId: d.tabId, started: d.timeStamp });
}
function netDone(d) {
  netTrackEnd(d);
  if (!capturing) return;
  const r = inflight.get(d.requestId); inflight.delete(d.requestId);
  if (r) captured.push({ ...r, status: d.statusCode, fromCache: d.fromCache, ms: Math.round(d.timeStamp - r.started) });
}
function netErr(d) {
  netTrackEnd(d);
  if (!capturing) return;
  const r = inflight.get(d.requestId); inflight.delete(d.requestId);
  if (r) captured.push({ ...r, error: d.error, ms: Math.round(d.timeStamp - r.started) });
}
try {
  chrome.webRequest.onBeforeRequest.addListener(netStart, { urls: ['<all_urls>'] });
  chrome.webRequest.onCompleted.addListener(netDone, { urls: ['<all_urls>'] });
  chrome.webRequest.onErrorOccurred.addListener(netErr, { urls: ['<all_urls>'] });
} catch (e) { console.warn('[chrome-bridge] webRequest unavailable', e); }

// ---- debugger helpers (upload_file, exec viaDebugger, network_capture bodies) ----
function dbg(target, method, params) {
  return new Promise((resolve, reject) => {
    chrome.debugger.sendCommand(target, method, params || {}, (res) => {
      const err = chrome.runtime.lastError;
      if (err) reject(new Error(err.message)); else resolve(res);
    });
  });
}
// Refcount attach so several features can share one debugger session on a tab
// without detaching out from under each other (e.g. exec while a body capture runs).
const dbgRefs = new Map(); // tabId -> attach count
async function dbgAttach(tabId) {
  const n = dbgRefs.get(tabId) || 0;
  if (n === 0) await chrome.debugger.attach({ tabId }, '1.3');
  dbgRefs.set(tabId, n + 1);
}
async function dbgDetach(tabId) {
  const n = dbgRefs.get(tabId) || 0;
  if (n <= 1) { dbgRefs.delete(tabId); try { await chrome.debugger.detach({ tabId }); } catch {} }
  else dbgRefs.set(tabId, n - 1);
}

// ---- debugger-based network capture WITH response bodies (one tab; shows the banner) ----
const NET_MAX = 100;              // cap requests kept per capture
const NET_BODY_CAP = 64 * 1024;   // cap each captured body (chars)
let dbgNet = null; // { tabId, reqs: Map<requestId, rec>, order: string[] } while capturing bodies
function onNetEvent(source, method, params) {
  const S = dbgNet;
  if (!S || source.tabId !== S.tabId) return;
  if (method === 'Network.requestWillBeSent') {
    if (!S.reqs.has(params.requestId) && S.reqs.size >= NET_MAX) return;
    S.reqs.set(params.requestId, {
      url: params.request.url, method: params.request.method,
      type: params.type, started: params.timestamp,
    });
    S.order.push(params.requestId);
  } else if (method === 'Network.responseReceived') {
    const r = S.reqs.get(params.requestId);
    if (r) { r.status = params.response.status; r.mimeType = params.response.mimeType; if (params.type) r.type = params.type; }
  } else if (method === 'Network.loadingFinished') {
    const r = S.reqs.get(params.requestId);
    if (!r || r._bodyDone) return;
    r._bodyDone = true;
    chrome.debugger.sendCommand({ tabId: S.tabId }, 'Network.getResponseBody', { requestId: params.requestId }, (res) => {
      if (chrome.runtime.lastError || !res) { r.bodyError = (chrome.runtime.lastError && chrome.runtime.lastError.message) || 'no body'; return; }
      const body = res.body || '';
      r.base64Encoded = !!res.base64Encoded;
      r.bodyBytes = body.length;
      r.bodyTruncated = body.length > NET_BODY_CAP;
      r.body = r.bodyTruncated ? body.slice(0, NET_BODY_CAP) : body;
    });
  } else if (method === 'Network.loadingFailed') {
    const r = S.reqs.get(params.requestId);
    if (r) r.error = params.errorText;
  }
}
chrome.debugger.onEvent.addListener(onNetEvent);
// Held CDP overrides that persist while the debugger stays attached (emulate_media).
// Tracked so we don't stack refcounts on repeat calls and can release on reset.
const mediaEmu = new Set(); // tabIds with a held setEmulatedMedia override

// If the user cancels the debugger banner (or the tab closes), forget that tab's state.
chrome.debugger.onDetach.addListener((source) => {
  if (source.tabId == null) return;
  dbgRefs.delete(source.tabId);
  mediaEmu.delete(source.tabId);
  if (dbgNet && dbgNet.tabId === source.tabId) dbgNet = null;
});

// key -> CDP key event fields for the common non-printable keys. Single characters
// fall back to typing the char itself (see press_key).
const KEY_TABLE = {
  // Enter carries text '\r' so it dispatches as keyDown (with a keypress), which is
  // what triggers a form's implicit submission / newline — rawKeyDown alone doesn't.
  Enter: { code: 'Enter', keyCode: 13, text: '\r' },
  Tab: { code: 'Tab', keyCode: 9 },
  Escape: { code: 'Escape', keyCode: 27 },
  Backspace: { code: 'Backspace', keyCode: 8 },
  Delete: { code: 'Delete', keyCode: 46 },
  ArrowUp: { code: 'ArrowUp', keyCode: 38 },
  ArrowDown: { code: 'ArrowDown', keyCode: 40 },
  ArrowLeft: { code: 'ArrowLeft', keyCode: 37 },
  ArrowRight: { code: 'ArrowRight', keyCode: 39 },
  Home: { code: 'Home', keyCode: 36 },
  End: { code: 'End', keyCode: 35 },
  PageUp: { code: 'PageUp', keyCode: 33 },
  PageDown: { code: 'PageDown', keyCode: 34 },
  Space: { code: 'Space', keyCode: 32, text: ' ' },
};
const KEY_MODIFIER_BITS = { Alt: 1, Control: 2, Meta: 4, Shift: 8 };

async function handle(action, p) {
  lastAction = action;
  lastActionAt = Date.now();
  commandCount++;
  try { chrome.storage.local.set({ commandCount, lastAction, lastActionAt }); } catch {}
  switch (action) {
    case 'list_tabs': {
      const tabs = await chrome.tabs.query({});
      return tabs.map((t) => ({ tabId: t.id, url: t.url, title: t.title, active: t.active }));
    }

    case 'navigate': {
      const tabId = requireTab(p);
      // No { active: true } → tab updates in place without being focused/raised.
      await chrome.tabs.update(tabId, { url: p.url });
      return { ok: true, tabId, url: p.url };
    }

    case 'exec': {
      const tabId = requireTab(p);
      // Opt-in path for strict-CSP pages (GitHub, Google, some banks): the page's
      // CSP forbids MAIN-world new Function, but the DevTools protocol's Runtime.evaluate
      // is not subject to it. Costs the "debugging this browser" banner for the call.
      if (p.viaDebugger) {
        await dbgAttach(tabId);
        try {
          const r = await dbg({ tabId }, 'Runtime.evaluate', {
            expression: '(async () => {\n' + String(p.code) + '\n})()',
            awaitPromise: true,
            returnByValue: true,
            userGesture: false,
          });
          if (r && r.exceptionDetails) {
            const ex = r.exceptionDetails;
            const msg = (ex.exception && (ex.exception.description || ex.exception.value)) || ex.text || 'exec error';
            throw new Error(String(msg));
          }
          return r && r.result ? r.result.value : undefined;
        } finally {
          await dbgDetach(tabId);
        }
      }
      const [res] = await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        args: [String(p.code)],
        func: (code) => {
          // AsyncFunction so the caller's code can use `return` and `await`.
          const AsyncFunction = Object.getPrototypeOf(async function () {}).constructor;
          return AsyncFunction(code)(); // executeScript awaits the returned promise
        },
      });
      return res?.result;
    }

    case 'read': {
      const tabId = requireTab(p);
      const format = p.format || (p.html ? 'html' : 'text');
      const [res] = await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        args: [p.selector || null, format],
        func: (selector, format) => {
          const el = selector ? document.querySelector(selector) : document.documentElement;
          if (!el) return null;
          if (format === 'html') return el.outerHTML;
          if (format !== 'markdown') return el.innerText || el.textContent || '';
          // Lightweight, dependency-free DOM → Markdown of the main content.
          const scope = selector ? el : (document.querySelector('main') || document.querySelector('article') || document.body);
          if (!scope) return '';
          const SKIP = new Set(['SCRIPT', 'STYLE', 'NOSCRIPT', 'NAV', 'ASIDE', 'FOOTER', 'FORM', 'SVG', 'TEMPLATE', 'IFRAME']);
          const ser = (node) => {
            let out = '';
            for (const child of node.childNodes) {
              if (child.nodeType === 3) { out += child.textContent.replace(/\s+/g, ' '); continue; }
              if (child.nodeType !== 1) continue;
              const tag = child.tagName;
              if (SKIP.has(tag)) continue;
              let hidden = false;
              try { const s = getComputedStyle(child); hidden = s.display === 'none' || s.visibility === 'hidden'; } catch {}
              if (hidden) continue;
              if (/^H[1-6]$/.test(tag)) { out += '\n\n' + '#'.repeat(+tag[1]) + ' ' + child.innerText.trim() + '\n\n'; continue; }
              if (tag === 'P') { out += '\n\n' + ser(child).trim() + '\n\n'; continue; }
              if (tag === 'BR') { out += '\n'; continue; }
              if (tag === 'HR') { out += '\n\n---\n\n'; continue; }
              if (tag === 'A') { const h = child.getAttribute('href'); const t = child.innerText.trim(); out += h && t ? '[' + t + '](' + h + ')' : t; continue; }
              if (tag === 'STRONG' || tag === 'B') { out += '**' + ser(child).trim() + '**'; continue; }
              if (tag === 'EM' || tag === 'I') { out += '*' + ser(child).trim() + '*'; continue; }
              if (tag === 'CODE' && child.closest('pre') === null) { out += '`' + child.innerText + '`'; continue; }
              if (tag === 'PRE') { out += '\n\n```\n' + child.innerText.replace(/\n$/, '') + '\n```\n\n'; continue; }
              if (tag === 'LI') { out += '\n- ' + ser(child).trim().replace(/\n/g, ' '); continue; }
              if (tag === 'UL' || tag === 'OL') { out += '\n' + ser(child) + '\n'; continue; }
              if (tag === 'IMG') { const alt = child.getAttribute('alt') || ''; const src = child.getAttribute('src') || ''; out += alt && src ? '![' + alt + '](' + src + ')' : ''; continue; }
              if (tag === 'BLOCKQUOTE') { out += '\n\n> ' + ser(child).trim().replace(/\n+/g, '\n> ') + '\n\n'; continue; }
              out += ser(child);
              if (tag === 'DIV' || tag === 'SECTION' || tag === 'ARTICLE' || tag === 'TR') out += '\n';
            }
            return out;
          };
          return ser(scope).replace(/[ \t]+\n/g, '\n').replace(/\n{3,}/g, '\n\n').trim();
        },
      });
      return res?.result;
    }

    case 'snapshot': {
      const tabId = requireTab(p);
      const [res] = await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        args: [p.selector || null, p.interactiveOnly !== false],
        func: (rootSel, interactiveOnly) => {
          let counter = 0;
          const CAP = 2000;
          const SIMPLE = new Set(['A', 'BUTTON', 'INPUT', 'SELECT', 'TEXTAREA']);
          const LANDMARK = new Set(['MAIN', 'NAV', 'HEADER', 'FOOTER', 'ASIDE', 'FORM', 'SECTION']);
          const visible = (el) => {
            if (el.getAttribute('aria-hidden') === 'true') return false;
            let s; try { s = getComputedStyle(el); } catch { return true; }
            if (s.display === 'none' || s.visibility === 'hidden') return false;
            const r = el.getBoundingClientRect();
            return !(r.width === 0 && r.height === 0);
          };
          const roleOf = (el) => {
            const explicit = el.getAttribute('role');
            if (explicit) return explicit;
            const tag = el.tagName;
            if (tag === 'A') return 'link';
            if (tag === 'BUTTON') return 'button';
            if (tag === 'INPUT') {
              const t = (el.getAttribute('type') || 'text').toLowerCase();
              if (t === 'checkbox') return 'checkbox';
              if (t === 'radio') return 'radio';
              if (t === 'submit' || t === 'button' || t === 'reset') return 'button';
              if (t === 'search') return 'searchbox';
              if (t === 'hidden') return 'hidden';
              return 'textbox';
            }
            if (tag === 'SELECT') return 'combobox';
            if (tag === 'TEXTAREA') return 'textbox';
            if (tag === 'MAIN') return 'main';
            if (tag === 'NAV') return 'navigation';
            if (tag === 'HEADER') return 'banner';
            if (tag === 'FOOTER') return 'contentinfo';
            if (tag === 'FORM') return 'form';
            if (/^H[1-6]$/.test(tag)) return 'heading';
            return tag.toLowerCase();
          };
          const accName = (el) => {
            const al = el.getAttribute('aria-label');
            if (al && al.trim()) return al.trim();
            const lb = el.getAttribute('aria-labelledby');
            if (lb) {
              const txt = lb.split(/\s+/).map((id) => { const n = document.getElementById(id); return n ? n.innerText : ''; }).join(' ').trim();
              if (txt) return txt;
            }
            if (el.id) { try { const lab = document.querySelector('label[for="' + CSS.escape(el.id) + '"]'); if (lab && lab.innerText.trim()) return lab.innerText.trim(); } catch {} }
            const wrap = el.closest && el.closest('label');
            if (wrap && wrap.innerText.trim()) return wrap.innerText.trim();
            for (const a of ['placeholder', 'title', 'alt', 'value']) { const v = el.getAttribute(a); if (v && v.trim()) return v.trim(); }
            return (el.innerText || el.textContent || '').trim().replace(/\s+/g, ' ').slice(0, 120);
          };
          const interactive = (el) => {
            if (SIMPLE.has(el.tagName)) return !(el.tagName === 'A' && !el.hasAttribute('href'));
            if (el.tagName === 'SUMMARY') return true;
            if (el.hasAttribute('role')) return true;
            if (el.hasAttribute('onclick')) return true;
            if (el.getAttribute('contenteditable') === 'true') return true;
            return false;
          };
          const lines = [];
          const root = rootSel ? document.querySelector(rootSel) : document.body;
          if (!root) return null;
          const walk = (el, depth) => {
            for (const child of Array.from(el.children)) {
              if (counter >= CAP) return;
              if (!visible(child)) continue;
              const act = interactive(child);
              const isHead = /^H[1-6]$/.test(child.tagName);
              const isLand = LANDMARK.has(child.tagName);
              const roleName = act ? roleOf(child) : null;
              if (roleName === 'hidden') continue;
              const emit = act || (!interactiveOnly && (isLand || isHead));
              if (emit) {
                const ref = 'e' + (++counter);
                child.setAttribute('data-cb-ref', ref);
                const r = roleOf(child);
                const name = accName(child);
                const states = [];
                if (child.disabled) states.push('disabled');
                if (child.checked) states.push('checked');
                const exp = child.getAttribute('aria-expanded');
                if (exp) states.push('expanded=' + exp);
                const nameStr = name ? ' "' + name.replace(/"/g, "'") + '"' : '';
                const stateStr = states.length ? ' [' + states.join(', ') + ']' : '';
                lines.push('  '.repeat(depth) + '- ' + r + nameStr + ' [ref=' + ref + ']' + stateStr);
              }
              if (!(act && SIMPLE.has(child.tagName))) walk(child, emit ? depth + 1 : depth);
            }
          };
          walk(root, 0);
          const body = lines.join('\n');
          const note = counter >= CAP ? '\n… (truncated at ' + CAP + ' elements)' : '';
          return body ? body + note : '(no matching elements found)';
        },
      });
      return res?.result;
    }

    case 'click': {
      const tabId = requireTab(p);
      const [res] = await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        args: [p.ref || null, p.selector || null],
        func: (ref, selector) => {
          const sel = ref ? '[data-cb-ref="' + ref + '"]' : selector;
          if (!sel) return { ok: false, error: 'need ref or selector' };
          const el = document.querySelector(sel);
          if (!el) return { ok: false, error: 'not found: ' + sel };
          el.scrollIntoView({ block: 'center', inline: 'center' });
          el.click();
          return { ok: true, clicked: sel };
        },
      });
      return res?.result;
    }

    case 'fill': {
      const tabId = requireTab(p);
      const [res] = await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        args: [p.ref || null, p.selector || null, String(p.value ?? ''), !!p.submit],
        func: (ref, selector, value, submit) => {
          const sel = ref ? '[data-cb-ref="' + ref + '"]' : selector;
          if (!sel) return { ok: false, error: 'need ref or selector' };
          const el = document.querySelector(sel);
          if (!el) return { ok: false, error: 'not found: ' + sel };
          el.focus();
          if (el.isContentEditable) {
            el.textContent = value;
          } else {
            // Use the native setter so React/Vue value trackers notice the change.
            const proto = el.tagName === 'TEXTAREA' ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
            const desc = Object.getOwnPropertyDescriptor(proto, 'value');
            if (desc && desc.set && (el.tagName === 'INPUT' || el.tagName === 'TEXTAREA')) desc.set.call(el, value);
            else el.value = value;
          }
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
          if (submit) {
            const form = el.form || (el.closest && el.closest('form'));
            el.dispatchEvent(new KeyboardEvent('keydown', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
            el.dispatchEvent(new KeyboardEvent('keyup', { key: 'Enter', code: 'Enter', keyCode: 13, which: 13, bubbles: true }));
            if (form) { if (form.requestSubmit) form.requestSubmit(); else form.submit(); }
          }
          return { ok: true, filled: sel };
        },
      });
      return res?.result;
    }

    case 'hover': {
      const tabId = requireTab(p);
      const [res] = await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        args: [p.ref || null, p.selector || null],
        func: (ref, selector) => {
          const sel = ref ? '[data-cb-ref="' + ref + '"]' : selector;
          if (!sel) return { ok: false, error: 'need ref or selector' };
          const el = document.querySelector(sel);
          if (!el) return { ok: false, error: 'not found: ' + sel };
          el.scrollIntoView({ block: 'center' });
          const r = el.getBoundingClientRect();
          const opts = { bubbles: true, cancelable: true, view: window, clientX: r.left + r.width / 2, clientY: r.top + r.height / 2 };
          for (const type of ['pointerover', 'pointerenter', 'mouseover', 'mouseenter', 'pointermove', 'mousemove']) {
            const Ctor = type.startsWith('pointer') && typeof PointerEvent !== 'undefined' ? PointerEvent : MouseEvent;
            el.dispatchEvent(new Ctor(type, opts));
          }
          return { ok: true, hovered: sel };
        },
      });
      return res?.result;
    }

    case 'wait_for': {
      const tabId = requireTab(p);
      const timeoutMs = p.timeoutMs || 10000;
      const start = Date.now();
      if (p.networkIdle) {
        // Settle: no in-flight requests for this tab for `idleMs` of quiet.
        const idleMs = p.idleMs || 500;
        while (Date.now() - start < timeoutMs) {
          const set = netInflight.get(tabId);
          const inFlight = set ? set.size : 0;
          const last = netLastActivity.get(tabId) || 0;
          if (inFlight === 0 && Date.now() - last >= idleMs) return { ok: true, waitedMs: Date.now() - start };
          await new Promise((r) => setTimeout(r, 100));
        }
        throw new Error('wait_for networkIdle timed out after ' + timeoutMs + 'ms');
      }
      const check = async () => {
        try {
          const [r] = await chrome.scripting.executeScript({
            target: { tabId },
            world: 'MAIN',
            args: [p.selector || null, p.text || null, !!p.gone],
            func: (selector, text, gone) => {
              let found;
              if (selector) found = !!document.querySelector(selector);
              else if (text) found = (document.body ? document.body.innerText : '').includes(text);
              else found = document.readyState === 'complete';
              return gone ? !found : found;
            },
          });
          return r && r.result;
        } catch { return false; }
      };
      while (Date.now() - start < timeoutMs) {
        if (await check()) return { ok: true, waitedMs: Date.now() - start };
        await new Promise((r) => setTimeout(r, 250));
      }
      throw new Error('wait_for timed out after ' + timeoutMs + 'ms');
    }

    case 'console_capture': {
      const tabId = requireTab(p);
      if (p.action === 'start') {
        await chrome.scripting.executeScript({
          target: { tabId },
          world: 'MAIN',
          func: () => {
            if (window.__cbConsoleInstalled) { window.__cbConsole = []; return; }
            window.__cbConsoleInstalled = true;
            window.__cbConsole = [];
            const CAP = 1000;
            const push = (level, args) => {
              try {
                if (window.__cbConsole.length >= CAP) return;
                const text = args.map((a) => { try { return typeof a === 'string' ? a : JSON.stringify(a); } catch { return String(a); } }).join(' ').slice(0, 2000);
                window.__cbConsole.push({ level, text, t: Date.now() });
              } catch {}
            };
            for (const m of ['log', 'info', 'warn', 'error', 'debug']) {
              const orig = console[m].bind(console);
              console[m] = (...args) => { push(m, args); orig(...args); };
            }
            window.addEventListener('error', (e) => push('error', [(e.message || 'error') + ' @ ' + (e.filename || '') + ':' + (e.lineno || '')]));
            window.addEventListener('unhandledrejection', (e) => push('error', ['unhandledrejection: ' + ((e.reason && e.reason.message) || e.reason)]));
          },
        });
        return { ok: true, capturing: true };
      }
      const [res] = await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        func: () => { const logs = window.__cbConsole || []; window.__cbConsole = []; return logs; },
      });
      const logs = (res && res.result) || [];
      return { count: logs.length, logs };
    }

    case 'cookies': {
      let url = p.url;
      if (!url) {
        const tabId = requireTab(p);
        const tab = await chrome.tabs.get(tabId);
        url = tab.url;
      }
      const cookies = await chrome.cookies.getAll({ url });
      return {
        url,
        count: cookies.length,
        cookies: cookies.map((c) => ({ name: c.name, value: c.value, domain: c.domain, path: c.path, secure: c.secure, httpOnly: c.httpOnly, session: c.session, expires: c.expirationDate })),
      };
    }

    case 'open_tab': {
      if (p.newWindow || p.incognito) {
        const win = await chrome.windows.create({ url: p.url || 'about:blank', incognito: !!p.incognito, focused: !!p.active });
        const t = win.tabs && win.tabs[0];
        return { tabId: t && t.id, windowId: win.id, incognito: win.incognito };
      }
      const t = await chrome.tabs.create({ url: p.url || 'about:blank', active: !!p.active });
      return { tabId: t.id, windowId: t.windowId, active: t.active };
    }

    case 'close_tab': {
      await chrome.tabs.remove(p.tabId);
      return { ok: true };
    }

    case 'screenshot': {
      const tabId = requireTab(p);
      // CDP path: render off-screen at a controlled viewport and/or clip to one element.
      // No focus change and no real-window resize (unlike captureVisibleTab below).
      const emulate = p.width && p.height;
      if (emulate || p.selector) {
        await dbgAttach(tabId);
        try {
          if (emulate) {
            await dbg({ tabId }, 'Emulation.setDeviceMetricsOverride', {
              width: p.width, height: p.height,
              deviceScaleFactor: p.deviceScaleFactor ?? 2,
              mobile: p.mobile ?? true,
            });
          }
          const shotParams = { format: 'png', captureBeyondViewport: !!p.fullPage };
          if (p.selector) {
            // Measure the element (in the emulated layout, if any) to clip the capture.
            const r = await dbg({ tabId }, 'Runtime.evaluate', {
              expression:
                '(() => { const el = document.querySelector(' + JSON.stringify(p.selector) + ');' +
                ' if (!el) return null; el.scrollIntoView({ block: "center", inline: "center" });' +
                ' const b = el.getBoundingClientRect();' +
                ' return { x: b.left + window.scrollX, y: b.top + window.scrollY, width: b.width, height: b.height }; })()',
              returnByValue: true,
            });
            const box = r && r.result && r.result.value;
            if (!box) throw new Error('screenshot: element not found: ' + p.selector);
            if (box.width < 1 || box.height < 1) throw new Error('screenshot: element has zero size: ' + p.selector);
            shotParams.clip = { x: box.x, y: box.y, width: box.width, height: box.height, scale: 1 };
            shotParams.captureBeyondViewport = true; // element may be outside the current viewport
          }
          const { data } = await dbg({ tabId }, 'Page.captureScreenshot', shotParams);
          return { dataUrl: 'data:image/png;base64,' + data };
        } finally {
          if (emulate) await dbg({ tabId }, 'Emulation.clearDeviceMetricsOverride').catch(() => {});
          await dbgDetach(tabId);
        }
      }
      const tab = await chrome.tabs.get(tabId);
      const [prev] = await chrome.tabs.query({ active: true, windowId: tab.windowId });
      const flash = !tab.active; // only touch focus if we must render a background tab
      if (flash) { await chrome.tabs.update(tabId, { active: true }); await new Promise((r) => setTimeout(r, 180)); }
      const dataUrl = await chrome.tabs.captureVisibleTab(tab.windowId, { format: 'png' });
      if (flash && prev) await chrome.tabs.update(prev.id, { active: true });
      return { dataUrl };
    }

    case 'press_key': {
      const tabId = requireTab(p);
      const key = p.key;
      if (!key || typeof key !== 'string') throw new Error('press_key: key is required (e.g. "Enter", "Escape", "a").');
      const mods = Array.isArray(p.modifiers) ? p.modifiers : [];
      let modifiers = 0;
      for (const m of mods) {
        if (!(m in KEY_MODIFIER_BITS)) throw new Error('press_key: unknown modifier "' + m + '" (use Alt|Control|Meta|Shift).');
        modifiers |= KEY_MODIFIER_BITS[m];
      }
      const known = KEY_TABLE[key];
      // Single printable char (no named key): type it as text; else use the table.
      const printable = !known && key.length === 1;
      const code = known ? known.code : (printable ? 'Key' + key.toUpperCase() : key);
      const keyCode = known ? known.keyCode : (printable ? key.toUpperCase().charCodeAt(0) : 0);
      // A char is emitted for printable keys (and Space) unless a non-Shift modifier is held.
      const hasNonShift = mods.some((m) => m !== 'Shift');
      const text = known ? known.text : (printable ? key : undefined);
      await dbgAttach(tabId);
      try {
        if (p.selector) {
          const r = await dbg({ tabId }, 'Runtime.evaluate', {
            expression: '(() => { const el = document.querySelector(' + JSON.stringify(p.selector) + '); if (!el) return false; el.focus(); return true; })()',
            returnByValue: true,
          });
          if (!(r && r.result && r.result.value)) throw new Error('press_key: element not found to focus: ' + p.selector);
        }
        const base = { modifiers, key, code, windowsVirtualKeyCode: keyCode, nativeVirtualKeyCode: keyCode };
        await dbg({ tabId }, 'Input.dispatchKeyEvent', {
          type: (text && !hasNonShift) ? 'keyDown' : 'rawKeyDown',
          ...base, ...(text && !hasNonShift ? { text } : {}),
        });
        await dbg({ tabId }, 'Input.dispatchKeyEvent', { type: 'keyUp', ...base });
        return { ok: true, key };
      } finally {
        await dbgDetach(tabId);
      }
    }

    case 'select': {
      const tabId = requireTab(p);
      const [res] = await chrome.scripting.executeScript({
        target: { tabId },
        world: 'MAIN',
        args: [p.ref || null, p.selector || null, p.value ?? null, p.label ?? null, p.index ?? null],
        func: (ref, selector, value, label, index) => {
          const sel = ref ? '[data-cb-ref="' + ref + '"]' : selector;
          if (!sel) return { ok: false, error: 'need ref or selector' };
          const el = document.querySelector(sel);
          if (!el) return { ok: false, error: 'not found: ' + sel };
          if (el.tagName !== 'SELECT') return { ok: false, error: 'not a <select>: ' + sel };
          const opts = Array.from(el.options);
          let match = null;
          if (index != null) match = opts[index] || null;
          else if (value != null) match = opts.find((o) => o.value === String(value)) || null;
          else if (label != null) match = opts.find((o) => (o.textContent || '').trim() === String(label).trim()) || null;
          else return { ok: false, error: 'provide one of value, label, or index' };
          if (!match) return { ok: false, error: 'no matching option' };
          el.value = match.value;
          el.dispatchEvent(new Event('input', { bubbles: true }));
          el.dispatchEvent(new Event('change', { bubbles: true }));
          return { ok: true, value: match.value, label: (match.textContent || '').trim() };
        },
      });
      const r = res && res.result;
      if (r && r.ok === false) throw new Error('select: ' + r.error);
      return r;
    }

    case 'emulate_media': {
      const tabId = requireTab(p);
      // Overrides persist ONLY while the debugger stays attached, so we HOLD the
      // attachment (a session) until reset:true releases it. Repeat sets are idempotent.
      if (p.reset) {
        if (mediaEmu.has(tabId)) {
          await dbg({ tabId }, 'Emulation.setEmulatedMedia', { media: '', features: [] }).catch(() => {});
          mediaEmu.delete(tabId);
          await dbgDetach(tabId);
        }
        return { ok: true, reset: true };
      }
      const features = [];
      if (p.colorScheme) features.push({ name: 'prefers-color-scheme', value: p.colorScheme });
      if (p.reducedMotion) features.push({ name: 'prefers-reduced-motion', value: p.reducedMotion });
      if (!features.length && !p.media) throw new Error('emulate_media: provide colorScheme, reducedMotion, media, or reset:true.');
      if (!mediaEmu.has(tabId)) { await dbgAttach(tabId); mediaEmu.add(tabId); }
      try {
        await dbg({ tabId }, 'Emulation.setEmulatedMedia', { media: p.media || '', features });
      } catch (e) {
        // Roll back the held attach if the command failed, so we don't leak a ref.
        if (mediaEmu.has(tabId)) { mediaEmu.delete(tabId); await dbgDetach(tabId).catch(() => {}); }
        throw e;
      }
      return { ok: true, colorScheme: p.colorScheme, reducedMotion: p.reducedMotion, media: p.media || null };
    }

    case 'upload_file': {
      const tabId = requireTab(p);
      const target = { tabId };
      await dbgAttach(tabId);
      try {
        const doc = await dbg(target, 'DOM.getDocument', { depth: -1 });
        const found = await dbg(target, 'DOM.querySelector', { nodeId: doc.root.nodeId, selector: p.selector });
        if (!found || !found.nodeId) throw new Error('file input not found: ' + p.selector);
        await dbg(target, 'DOM.setFileInputFiles', { nodeId: found.nodeId, files: p.filePaths });
        return { ok: true, files: p.filePaths };
      } finally {
        await dbgDetach(tabId);
      }
    }

    case 'network_capture': {
      if (p.action === 'start') {
        if (p.bodies) {
          // Response bodies need the debugger's Network domain, which targets ONE tab.
          if (p.tabId == null) throw new Error('network_capture bodies:true requires a tabId (the debugger targets one tab)');
          if (dbgNet) throw new Error('a body capture is already running on tab ' + dbgNet.tabId + '; stop it first');
          await dbgAttach(p.tabId);
          try { await dbg({ tabId: p.tabId }, 'Network.enable', {}); }
          catch (e) { await dbgDetach(p.tabId); throw e; }
          dbgNet = { tabId: p.tabId, reqs: new Map(), order: [] };
          return { ok: true, capturing: true, tabId: p.tabId, bodies: true };
        }
        capturing = true; captureTabId = p.tabId ?? null; captured = []; inflight.clear();
        return { ok: true, capturing: true, tabId: captureTabId };
      }
      // stop
      if (dbgNet) {
        const S = dbgNet;
        // Let any in-flight getResponseBody callbacks settle before we read them.
        await new Promise((r) => setTimeout(r, 200));
        dbgNet = null;
        try { await dbg({ tabId: S.tabId }, 'Network.disable', {}); } catch {}
        await dbgDetach(S.tabId);
        const requests = S.order.map((id) => {
          const r = S.reqs.get(id);
          if (!r) return null;
          const { started, _bodyDone, ...rest } = r;
          return rest;
        }).filter(Boolean);
        return { count: requests.length, bodies: true, tabId: S.tabId, requests };
      }
      capturing = false;
      const requests = captured; captured = []; inflight.clear();
      return { count: requests.length, requests };
    }

    case 'ping': {
      const tabs = await chrome.tabs.query({});
      return {
        pong: true,
        version: chrome.runtime.getManifest().version,
        connectedSince, commandCount, lastAction, lastActionAt,
        tabCount: tabs.length,
        debuggerTabs: [...dbgRefs.keys()],
        bodyCaptureTab: dbgNet ? dbgNet.tabId : null,
        now: Date.now(),
      };
    }

    default:
      throw new Error('Unknown action: ' + action);
  }
}

// Popup status/reconnect.
chrome.runtime.onMessage.addListener((req, _sender, sendResponse) => {
  const snapshot = () => ({ connected, connectedSince, lastAction, lastActionAt, commandCount, port: PORT });
  if (req?.type === 'status') sendResponse(snapshot());
  else if (req?.type === 'reconnect') { try { ws && ws.close(); } catch {} connect(); sendResponse(snapshot()); }
  return true;
});
