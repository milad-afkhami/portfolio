# Insured Vibe Coding source bundle

This package contains two unchanged authored skills:

- insured-vibe-coding/SKILL.md: current-state tracking, phase-based implementation,
  scenario tests, planned real-app QA and evidence before completion.
- testing-philosophy/SKILL.md: the testing principles referenced by the workflow.

Register both named folders using your agent host's supported skill-installation
process. The workflow is instruction text, not an executable runner. It assumes an
existing specification or PRD and a project with usable build/test/application tools.
The main skill's first-adoption step registers the process in the relevant project
AGENTS.md and/or CLAUDE.md; read that behavior before enabling it.

## External skills required separately

Install the complete Superpowers skill package through its supported distribution,
rather than copying only the few files named here. The workflow calls for:

- writing-plans before implementing a phase;
- test-driven-development during implementation;
- systematic-debugging when something fails;
- brainstorming when the phase has a genuine unresolved design question.

These skills can call additional skills from their package. Install that package
with its own supporting files and notices. This archive does not vendor it.

Frontend/UI phases also require frontend-design. That separate plugin/skill is not
included. Pure backend phases do not need a frontend design step.

The application still needs its own test runner and execution environment. UI QA
needs a browser-driving tool and access to an appropriate running test application.
The prompt prefers separate QA execution when supported; it does not create an
agent host, browser connection, credentials or background scheduler.

## Use

Explicitly ask your agent to use insured-vibe-coding with an agreed feature spec,
or adopt it deliberately in the project instruction file. Let the spec carry the
actual feature rules. Do not activate it just because someone mentions testing.

The phase outline groups implementation and testing at a high level while also
requesting test-driven development during the build. It is not a standalone program
that enforces a particular edit order. The source is unchanged, including its strong
coverage language; it should not be read as a measured guarantee of correctness.

## Provenance

Both SKILL.md files are exact source snapshots from Milad Afkhami's authored agent
toolkit on26October2026. No canonical skill was edited while preparing the bundle.
No explicit license file was supplied in these two authored skill directories or
the toolkit root; no new license grant has been added here. Separately installed
third-party packages retain their own source and license notices.
